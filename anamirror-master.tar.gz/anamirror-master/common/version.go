package common

const Version string = "1.0.0"

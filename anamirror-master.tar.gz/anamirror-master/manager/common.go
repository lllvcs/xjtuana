package manager

import (
	"gopkg.in/op/go-logging.v1"
)

var logger = logging.MustGetLogger("anamirror")

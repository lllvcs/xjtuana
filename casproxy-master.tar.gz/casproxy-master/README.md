# CAS Proxy

目前本服务已稳定运行在`XJTUANA`上。



 - CAS认证代理服务：允许其他未授权域名通过本域名代理登录
   +  有一个`trust.com`域名已经经过`CAS Server`授权
   +  别的域名`notrust.com`尚未经过`CAS Server`授权
   +  可以利用已授权的`trust.com`域名下的`CAS Proxy`服务，实现`notrust.com`下的代理认证

## Maintainer

 - xczh | [邮件联系我](xczh.me@foxmail.com)

有任何功能建议和`Bug`提交，欢迎邮件联系我或发`issue`。

## Usage

到[这里](https://git.xjtuana.com/xczh/cas-proxy/releases)下载预编译的二进制文件。

```sh
$ casproxy -v
CASProxy version 1.0beta1
Git Hash: 3b12d296a60ace935bc6b60258f33b983e6b9f68
Build Date: 2017-08-04 01:27:48 +0800 CST

For more information, run with '-h' option.
```

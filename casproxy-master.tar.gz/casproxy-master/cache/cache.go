package cache

import (
	"fmt"
	"runtime"
	"sync"
	"time"
)

type Item struct {
	Object     string
	Expiration int64
}

//return true if the item expirated
func (item Item) Expired() bool {
	if item.Expiration == 0 {
		return false
	}

	return time.Now().UnixNano() > item.Expiration
}

//use for outer struct
type Cache struct {
	*cache
}

type cache struct {
	name              string
	items             map[string]Item
	mu                sync.RWMutex
	onEvicted         func(string, string) //callback
	janitor           *janitor
}

// Add an item to the cache, replacing any existing item.
func (c *cache) Set(k string, x string, d time.Duration) {
	var e int64
	if d > 0 {
		e = time.Now().Add(d).UnixNano()
	}
	c.mu.Lock()
	c.items[k] = Item{
		Object:     x,
		Expiration: e,
	}
	c.mu.Unlock()
}

// Add an item to the cache only if an item doesn't already exist for the given
// key, or if the existing item has expired. Returns an error otherwise.
func (c *cache) Add(k string, x string, d time.Duration) error {
	c.mu.Lock()
	//check exit
	_, found := c.get(k)
	if found {
		err := fmt.Errorf("Item: %s has already exist", k)
		return err
	}
	//set
	c.set(k, x, d)
	c.mu.Unlock()
	return nil
}

func (c *cache) set(k string, x string, d time.Duration) {
	var e int64
	if d > 0 {
		e = time.Now().Add(d).UnixNano()
	}
	c.items[k] = Item{
		Object:     x,
		Expiration: e,
	}
}

// Delete an item from the cache. Does nothing if the key is not in the cache.
func (c *cache) Delete(k string) {
	c.mu.Lock()
	v, evicted := c.delete(k)
	c.mu.Unlock()
	if evicted {
		c.onEvicted(k, v)
	}
}

func (c *cache) delete(k string) (string, bool) {
	if c.onEvicted != nil {
		if v, found := c.items[k]; found {
			delete(c.items, k)
			return v.Object, true
		}
	}
	delete(c.items, k)
	return "", false
}

// Set a new value for the cache key only if it already exists, and the existing
// item hasn't expired. Returns an error otherwise.
func (c *cache) Replace(k string, x string, d time.Duration) error {
	c.mu.Lock()
	//check exit
	_, found := c.get(k)
	if !found {
		c.mu.Unlock()
		err := fmt.Errorf("Item: %s dosen't exist", k)
		return err
	}
	c.set(k, x, d)
	c.mu.Unlock()
	return nil
}

// Get an item from the cache. Returns the item or nil, and a bool indicating
// whether the key was found.
func (c *cache) Get(k string) (string, bool) {
	c.mu.RLock()
	item, found := c.items[k]
	c.mu.RUnlock()
	if !found {
		return "", false
	}
	//check item expired
	if item.Expiration > 0 && item.Expiration < time.Now().UnixNano() {
		return "", false
	}
	return item.Object, true
}

func (c *cache) get(k string) (string, bool) {
	item, found := c.items[k]
	if !found {
		return "", false
	}
	//check item expired
	if item.Expiration > 0 && item.Expiration < time.Now().UnixNano() {
		return "", false
	}
	return item.Object, true
}


type kv struct {
	key   string
	value string
}

// Delete all expired items from the cache.
func (c *cache) DeleteExpired() {
	var evictedItems []kv
	timeNow := time.Now().UnixNano()
	c.mu.Lock()
	for k, v := range c.items {
		if v.Expiration > 0 && v.Expiration < timeNow {
			v, evicted := c.delete(k)
			if evicted {
				evictedItems = append(evictedItems, kv{k, v})
			}
		}
	}
	c.mu.Unlock()
	for _, v := range evictedItems {
		c.onEvicted(v.key, v.value)
	}
}

//Return the item in the cache
func (c *cache) Item() map[string]Item {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.items
}

// Return the number of items in the cache. Equivalent to len(c.Items()).
func (c *cache) ItemCount() int {
	c.mu.Lock()
	n := len(c.items)
	c.mu.Unlock()
	return n
}

// Sets an (optional) function that is called with the key and value when an
// item is evicted from the cache. (Including when it is deleted manually, but
// not when it is overwritten.) Set to nil to disable.
func (c *cache) OnEvicted(f func(string, string)) {
	c.mu.Lock()
	c.onEvicted = f
	c.mu.Unlock()
}

// Delete all items from the cache.
func (c *cache) Flush() {
	c.mu.Lock()
	c.items = map[string]Item{}
	c.mu.Unlock()
}

type janitor struct {
	Interval time.Duration
	stop     chan bool
}

func (j *janitor) Run(c *cache) {
	j.stop = make(chan bool)
	ticker := time.NewTicker(j.Interval)
	for {
		select {
		case <-ticker.C:
			//delete expired
			c.DeleteExpired()
		case <-j.stop:
			ticker.Stop()
			return
		}
	}
}

func stopJanitor(c *Cache) {
	c.janitor.stop <- true
}

func runJanitor(c *cache, ci time.Duration) {
	j := &janitor{
		Interval: ci,
	}
	c.janitor = j
	go j.Run(c)
}

func NewCache(name string, cleanupInterval time.Duration) *Cache {
	items := make(map[string]Item)
	c := &cache{
		name:  name,
		items: items,
	}
	//init Cache
	C := &Cache{c}
	if cleanupInterval > 0 {
		runJanitor(c, cleanupInterval)
		runtime.SetFinalizer(C, stopJanitor)
	}
	return C
}

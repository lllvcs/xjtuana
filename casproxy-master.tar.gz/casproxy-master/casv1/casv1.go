package casv1

import (
	"bytes"
	"casproxy/cache"
	"casproxy/core"
	"casproxy/utils"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync/atomic"
	"time"
)

// login counter
var loginCounter uint64

// error counter
var errorCounter uint64

// memory UUID cache
var useridHash *cache.Cache = nil

// common HTTP Client
var httpClient = utils.NewHTTPClient()

// Route Function
// Should return a map contains path -> handler function
func Route() map[string]func(http.ResponseWriter, *http.Request) {
	return map[string]func(http.ResponseWriter, *http.Request){
		PATH_LOGIN:       LoginHandler,
		PATH_LOGOUT:      LogoutHandler,
		PATH_CALLBACK:    CallbackHandler,
		PATH_VERIFY:      VerifyHandler,
		PATH_TEST:        TestHandler,
		PATH_CACHE_ITEM:  CacheItemHandler,
		PATH_CACHE_FLUSH: CacheFlushHandler,
		PATH_STATUS:      StatusHandler,
	}
}

// Step1: Login Handler
//  - save 'redirect_url' to cookie
//  - redirect(302) to CAS Server to login
func LoginHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	redirect_url := query.Get("redirect_url")
	if redirect_url == "" {
		// request error, missing 'redirect_url' param
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50001,
			core.ERROR_MSG_50001,
		).MustJson())
		return
	}
	if !strings.HasPrefix(redirect_url, "http") {
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50002,
			core.ERROR_MSG_50002,
		).MustJson())
		return
	}
	// cache redirect_url
	cas_redirect_cookie := &http.Cookie{
		Name:     config.CookieRedirectUrl,
		Value:    redirect_url,
		Path:     "/",
		HttpOnly: true,
		Secure:   r.URL.Scheme == "https",
		MaxAge:   300,
	}
	http.SetCookie(w, cas_redirect_cookie)
	// redirect to CAS to login
	cas_login_url := config.CASServer + "/login?service=" + config.CASService
	http.Redirect(w, r, cas_login_url, 302)
}

func LogoutHandler(w http.ResponseWriter, r *http.Request) {
	cas_logout_url := config.CASServer + "/logout"
	http.Redirect(w, r, cas_logout_url, 302)
}

func CallbackHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	ticket := query.Get("ticket")
	if ticket == "" || !strings.HasPrefix(ticket, "ST-") {
		// missing 'ticket'
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50003,
			core.ERROR_MSG_50003,
		).MustJson())
		return
	}
	cookie_redirect_url, _ := r.Cookie(config.CookieRedirectUrl)
	if cookie_redirect_url == nil || !strings.HasPrefix(cookie_redirect_url.Value, "http") {
		// missing 'redirect_url'
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50004,
			core.ERROR_MSG_50004,
		).MustJson())
		return
	}
	redirect_url := cookie_redirect_url.Value
	// verify ticket with CAS Server
	res, err := httpClient.Get(config.CASServer + "/validate?service=" + config.CASService + "&ticket=" + ticket)
	if err != nil {
		// verify error
		log.Printf("verify error1: %v", err)
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50005,
			core.ERROR_MSG_50005,
		).MustJson())
		return
	}
	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		log.Printf("verify error: read response error, %v", err)
		atomic.AddUint64(&errorCounter, 1)
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50005,
			core.ERROR_MSG_50005,
		).MustJson())
		return
	}
	userid := ""

	if !bytes.Equal(body[0:3], []byte("yes")) {
		log.Printf("verify error3: %v", err)
		// verify failed
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50005,
			core.ERROR_MSG_50005,
		).MustJson())
		return
	}
	// verify success
	userid = string(body[4 : len(body)-1])
	atomic.AddUint64(&loginCounter, 1)
	log.Printf("[casv1] login callback ok: userid(%v)", userid)
	// set cache
	guid := Hash(fmt.Sprintf("%s-%d", userid, time.Now().UnixNano()))
	useridHash.Set(guid, userid, config.CacheItemExpireInternal)
	// redirect
	r_url, err := url.Parse(redirect_url)
	if err != nil {
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50006,
			core.ERROR_MSG_50006,
		).MustJson())
		return
	}
	rq := r_url.Query()
	rq.Set("guid", guid)
	r_url.RawQuery = rq.Encode()
	http.Redirect(w, r, r_url.String(), 302)
}

func VerifyHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	query_guid := query.Get("guid")
	if query_guid == "" {
		w.Write(core.NewResponseData(
			NewInvalidResult(),
		).MustJson())
		return
	}
	userid, _ := useridHash.Get(query_guid)
	if userid != "" {
		// valid
		useridHash.Delete(query_guid)
		w.Write(core.NewResponseData(
			NewValidResult(userid),
		).MustJson())
		return
	}
	w.Write(core.NewResponseData(
		NewInvalidResult(),
	).MustJson())
}

func TestHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	query_guid := query.Get("guid")
	if query_guid == "" {
		w.Write([]byte("no guid param found."))
		return
	}
	verify_url := config.BaseUrl + PATH_VERIFY + "?guid=" + query_guid
	res, err := httpClient.Get(verify_url)
	if err != nil {
		log.Printf("test: http error %s", err)
		return
	}
	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		log.Printf("test: ioutil error %s", err)
		return
	}
	w.Write(body)
}

func CacheItemHandler(w http.ResponseWriter, r *http.Request) {
	w.Write(core.NewResponseData(
		useridHash.Item(),
	).MustJson())
}

func CacheFlushHandler(w http.ResponseWriter, r *http.Request) {
	useridHash.Flush()
	w.Write(core.NewResponseData(nil).MustJson())
}

type StatusResponse struct {
	ErrorCount uint64 `json:"error_count"`
	LoginCount uint64 `json:"login_count"`
}

func StatusHandler(w http.ResponseWriter, r *http.Request) {
	w.Write(core.NewResponseData(StatusResponse{
		ErrorCount: errorCounter,
		LoginCount: loginCounter,
	}).MustJson())
}

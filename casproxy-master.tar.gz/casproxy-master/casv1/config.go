package casv1

import (
	"casproxy/cache"
	"casproxy/core"
	"fmt"
	"strings"
	"time"
)

type Config struct {
	BaseUrl string `json:"base_url"`
	// Config Fields
	CASServer               string        `json:"cas_server"`
	CASService              string        `json:"cas_service"`
	CookieRedirectUrl       string        `json:"cookie_redirect_url"`
	CacheCleanupInternal    time.Duration `json:"cache_cleanup_internal"`
	CacheItemExpireInternal time.Duration `json:"cache_item_expire_internal"`
}

// default config
var config = &Config{
	CookieRedirectUrl: DEFAULT_COOKIE_REDIRECT_URL,
}

func InitConfig(cc *core.Config) (err error) {
	if cc.CASServer != "" {
		if !strings.HasPrefix(cc.CASServer, "http") {
			err = fmt.Errorf("CAS Server Should start with 'http' or 'https'")
			return err
		}
		config.CASServer = cc.CASServer
	}
	config.BaseUrl = cc.GetBaseUrl()
	config.CASService = config.BaseUrl + PATH_CALLBACK
	if cc.CacheItemExpireInternal != 0 {
		config.CacheItemExpireInternal = time.Duration(cc.CacheItemExpireInternal) * time.Second
		config.CacheCleanupInternal = config.CacheItemExpireInternal * 2
	}
	// init module
	useridHash = cache.NewCache("casv1_cache", config.CacheCleanupInternal)
	return
}

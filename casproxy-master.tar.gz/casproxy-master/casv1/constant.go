package casv1

// route PATH
const PATH_LOGIN = "/v1/login"
const PATH_LOGOUT = "/v1/logout"
const PATH_CALLBACK = "/v1/callback"
const PATH_VERIFY = "/v1/verify"
const PATH_TEST = "/v1/test"

const PATH_CACHE_ITEM = "/v1/cache/item"
const PATH_CACHE_FLUSH = "/v1/cache/flush"

const PATH_STATUS = "/v1/status"

// default config
const DEFAULT_COOKIE_REDIRECT_URL = "casv1_redirect_url"

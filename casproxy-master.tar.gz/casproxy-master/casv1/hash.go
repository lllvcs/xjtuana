package casv1

import (
	"crypto/sha1"
	"encoding/hex"
)

func Hash(s string) string {
	b := sha1.Sum([]byte(s))
	return hex.EncodeToString(b[:])
}
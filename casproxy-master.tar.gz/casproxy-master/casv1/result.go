package casv1

import (
	"casproxy/xjtuws"
)

type CASV1Result struct {
	Ver      string      `json:"ver"`
	Userid   string      `json:"userid"`
	Userinfo interface{} `json:"userinfo"`
	Valid    bool        `json:"valid"`
}

func NewValidResult(userid string) *CASV1Result {
	pResult := &CASV1Result{
		Ver:    "v1",
		Userid: userid,
		Userinfo: nil,
		Valid:  true,
	}
	if config.CASServer == "https://cas.xjtu.edu.cn" {
		pUser, err := xjtuws.GetInfoByUserid(userid)
		if err == nil && pUser != nil {
			pResult.Userinfo = pUser
		}
	}
	return pResult
}

func NewInvalidResult() *CASV1Result {
	return &CASV1Result{
		Ver:    "v1",
		Userid: "",
		Valid:  false,
	}
}

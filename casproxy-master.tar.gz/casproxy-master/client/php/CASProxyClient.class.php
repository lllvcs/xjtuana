<?php

/**
 * CASProxy Client
 *
 * PHP Library for CASProxy Service
 *
 * @package    api
 *
 * @author     xczh <zhuxingchi@tiaozhan.com>
 *
 * @copyright  Copyright (C) 2017 xczh. All Rights Reserved.
 * @link       https://git.xjtuana.com/xczh/cas-proxy
 */

class CASProxyClient {
    protected $host = '';
    protected $protocol = '';
    protected $prefix = '/';
    protected $http_client = null;
    
    function __construct($host, $prefix, $use_https) {
        $this->host = $host;
        $this->prefix = $prefix;
        $this->protocol = $use_https ? 'https' : 'http';
        $this->http_client = new CurlHttpClient($use_https);
    }

    static public function getCurrentUrl()
    {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }

}

class CASProxyClientV1 extends CASProxyClient {
    
    static private $version = 'v1';
    private $post_login_hook = null;
    
    public function getBaseUrl() {
        return $this->protocol . '://' . $this->host . $this->prefix . '/' . self::$version;
    }
    
    protected function httpGet($path) {
        $result = $this->http_client->httpGet($this->getBaseUrl() . $path);
        if ($result[2]['http_code']!=200) {
            throw new CASProxyClientException("API Server Bad HTTP Code: ".$result[2]['http_code'], CASProxyClientException::E_API_ERROR);
        }
        $result[1] = json_decode($result[1], true);
        if ($result[1]['code'] != 0) {
            throw new CASProxyClientException("API Server Error: ".$result[1]['msg'], CASProxyClientException::E_API_ERROR);
        }
        return $result;
    }
    
    /**
     * 要求使用CAS登陆
     *
     * @param  $redirect_url  string  登陆完毕后浏览器将重定向回到此URL
     * @param  $return        bool    设置为为true时仅返回重定向目标URL，不发送Location头
     *
     */
    public function login($redirect_url='', $return = false) {
        if (!$redirect_url) {
            $redirect_url = parent::getCurrentUrl();
        }
        $url = $this->getBaseUrl() . '/login?redirect_url=' . urlencode($redirect_url);
        if ($return) {
            return $url;
        }
        header('Location: '.$url);
    }
    
    /**
     * 检查登陆完毕的用户身份GUID
     *
     * @param  $guid  string  登陆完毕后带回的GET参数guid
     *
     * @throws CASProxyClientException
     */
    public function verify($guid = '')
    {
        if (!$guid && isset($_SERVER['QUERY_STRING'])) {
            // if guid param is empty, try to obtain it from current QUERY_STRING
            parse_str($_SERVER['QUERY_STRING'], $parsed_array);
            if (true === array_key_exists('guid', $parsed_array)) {
                $guid = $parsed_array['guid'];
                unset($parsed_array);
            }
        }
        if (!$guid) {
            throw new CASProxyClientException('guid is empty', CASProxyClientException::E_GUID_EMPTY);
        }
        $result = $this->httpGet("/verify?guid=$guid");
        if ($this->post_login_hook) {
            return call_user_func($this->post_login_hook, $result[1]['data']);
        } else {
            return $result[1]['data'];
        }
    }
    
    /**
     * 注册自定义登陆回调函数(Post Login Hook)
     *
     * @param $post_login_hook  callable  登陆后触发的Hook，无返回值，调用后必须使得boolval(call_user_func($pre_login_hook))===true
     *                                    函数声明    function post_login_hook(array $user) $user为用户信息数组
     */
    public function registerLoginCallback(callable $post_login_hook)
    {
        if (true === is_callable($post_login_hook)) {
            $this->post_login_hook = $post_login_hook;
        } else {
            throw new CASProxyClientException(var_export($post_login_hook, true). ' is not a valid callable', CASProxyClientException::E_INVALID_PARAM);
        }
    }
    
    /**
     * 登出
     * 
     */
    public function logout() {
        header('Location: ' . $this->getBaseUrl() . '/logout');
    }
}

class CASProxyClientV1SessionContext {
    const DEFAULT_LOGIN_HOOK_SESSIONID = 'CASProxyClient';

    private $client = null;

    public function __construct(CASProxyClientV1 $client = null)
    {
        if (!$client) {
            throw new CASProxyClientException('session context require a CASProxyClient object to use.', CASProxyClientException::E_REQUIRE_CLIENT_OBJ);
        }
        $client->registerLoginCallback(function (array $user) {
            if (!empty($user) && !empty($user['userid'])) {
                self::ensureSessionStarted();
                $_SESSION[self::DEFAULT_LOGIN_HOOK_SESSIONID] = $user;
            }
        });
        $this->client = $client;
    }
    
    public function __call($func, $args)
    {
        if (true === is_callable(array($this->client, $func), false, $callable_name)) {
            return call_user_func_array(array(&$this->client, $callable_name), $args);
        }
        throw new CASProxyClientException('Called a not exist method ('. var_export($func, true). ')', CASProxyClientException::E_METHOD_NOT_EXISTS);
    }

    private static function isSessionStarted()
    {
        if (php_sapi_name() !== 'cli') {
            if (version_compare(phpversion(), '5.4.0', '>=')) {
                return session_status() === PHP_SESSION_ACTIVE ? true : false;
            } else {
                return session_id() === '' ? false : true;
            }
        }
        return false;
    }

    private static function ensureSessionStarted()
    {
        if (false === self::isSessionStarted()) {
            session_start();
        }
    }

    /**
     * 获取当前登陆用户信息
     *
     * @return  array  用户信息数组，若未登陆则返回空数组
     */
    public static function getLoginUser()
    {
        self::ensureSessionStarted();
        if (array_key_exists(self::DEFAULT_LOGIN_HOOK_SESSIONID, $_SESSION)) {
            return $_SESSION[self::DEFAULT_LOGIN_HOOK_SESSIONID];
        }
        return array();
    }

    /**
     * 判断用户是否已登陆
     *
     * @return bool 是否已登陆
     */
    public static function isLogined()
    {
        return boolval(self::getLoginUser());
    }

    /**
     * 强制用户登陆
     *
     * 用户已登陆则直接返回，未登陆则重定向至CAS进行认证
     *
     * @throws ClientV2Exception ClientException
     */
    public function forceLogin()
    {
        if ($this->isLogined()) {
            return;
        }
        try {
            $this->client->verify();
        } catch (CASProxyClientException $e) {
            if (CASProxyClientException::E_GUID_EMPTY == $e->getCode()) {
                $this->client->login();
            } else {
                throw $e;
            }
        }
    }
    
    /**
     * 强制用户登出
     *
     * 如果用户已登陆，则删除本Context的登录状态
     * 如果需要清除CAS系统的登录状态，会将浏览器重定向到CAS系统的登出页面
     *
     * @param $CASLogout boolean 是否清除CAS系统的登录状态
     */
    public function forceLogout($CASLogout = true)
    {
        if ($this->isLogined()) {
            self::ensureSessionStarted();
            $_SESSION[self::DEFAULT_LOGIN_HOOK_SESSIONID] = array();
        }
        if($CASLogout == true) {
            $this->client->logout();
        }
    }
}

/** Exceptions **/

class CASProxyClientException extends Exception
{
    const E_INVALID_PARAM = 10001;
    const E_BAD_ENVIRONMENT = 10002;
    const E_CURL_ERROR = 10003;
    
    const E_API_ERROR = 20001;
    const E_GUID_EMPTY = 20002;
    const E_METHOD_NOT_EXISTS = 20003;
    const E_REQUIRE_CLIENT_OBJ = 20004;
    

    public function __construct($message, $code = 0, Exception $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }

    public function __toString()
    {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }
}


/**
 * HTTP Client
 * 
 */
class CurlHttpClient {
    
    private $curl_version = null;
    private $curl_handle = null;
    
    public function __construct($enable_https = true) {
        if (!function_exists('curl_init') || !function_exists('curl_exec')) {
            throw new Exception('cURL extension is not found');
        } else {
            // cURL init
            $this->curl_version = curl_version();
            $this->curl_handle = curl_init();
            if ($enable_https && !(CURL_VERSION_SSL & $this->curl_version['features'])) {
                throw new Exception('your cURL extension not support HTTPS');
            }
            curl_setopt($this->curl_handle, CURLOPT_HEADER, false);
            curl_setopt($this->curl_handle, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($this->curl_handle, CURLOPT_ENCODING, '');
            if (defined('CURLOPT_PROTOCOLS')) {
                curl_setopt($this->curl_handle, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
            }
            if (defined('CURLOPT_REDIR_PROTOCOLS')) {
                curl_setopt($this->curl_handle, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
            }
        }
    }
    
    public function __destruct() {
        if (is_resource($this->curl_handle)) {
            curl_close($this->curl_handle);
        }
    }
    
    public function httpGet($url, $headers = array(), $options = array())
    {
        return self::httpRequest($url, $headers, null, 'GET', $options);
    }

    public function httpPost($url, $headers = array(), $data=array(), $options = array())
    {
        return self::httpRequest($url, $headers, $data, 'POST', $options);
    }

    public function httpRequest($url, $headers = array(), $data = array(), $type = 'GET', $options = array())
    {
        $default_options = array(
            'timeout' => 10,
            'connect_timeout' => 3,
            'useragent' => 'casproxy-client-php',
            'referer' => '',
            'need_header' => false,
            'need_body' => true,
        );
        $options = array_merge($default_options, $options);
        // process array or object type body
        if (!empty($data) && !is_string($data)) {
            $data = http_build_query($data, null, '&');
        }
        switch ($type) {
            case 'POST':
                curl_setopt($this->curl_handle, CURLOPT_POST, true);
                curl_setopt($this->curl_handle, CURLOPT_POSTFIELDS, $data);
                break;
            case 'HEAD':
                curl_setopt($this->curl_handle, CURLOPT_CUSTOMREQUEST, 'HEAD');
                curl_setopt($this->curl_handle, CURLOPT_NOBODY, true);
                break;
            case 'PATCH':
            case 'PUT':
            case 'DELETE':
            case 'OPTIONS':
            default:
                curl_setopt($this->curl_handle, CURLOPT_CUSTOMREQUEST, $type);
                if (!empty($data)) {
                    curl_setopt($this->curl_handle, CURLOPT_POSTFIELDS, $data);
                }
        }
        curl_setopt($this->curl_handle, CURLOPT_TIMEOUT, ceil($options['timeout']));
        curl_setopt($this->curl_handle, CURLOPT_CONNECTTIMEOUT, ceil($options['connect_timeout']));
        curl_setopt($this->curl_handle, CURLOPT_URL, $url);
        curl_setopt($this->curl_handle, CURLOPT_REFERER, $options['referer'] or $url);
        curl_setopt($this->curl_handle, CURLOPT_USERAGENT, $options['useragent']);
        curl_setopt($this->curl_handle, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        if (!empty($headers)) {
            curl_setopt($this->curl_handle, CURLOPT_HTTPHEADER, $headers);
        }

        curl_setopt($this->curl_handle, CURLOPT_HEADER, $options['need_header']);
        curl_setopt($this->curl_handle, CURLOPT_NOBODY, !$options['need_body']);

        if (isset($options['verify'])) {
            if ($options['verify'] === false) {
                curl_setopt($this->curl_handle, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($this->curl_handle, CURLOPT_SSL_VERIFYPEER, 0);
            } elseif (is_string($options['verify'])) {
                curl_setopt($this->curl_handle, CURLOPT_CAINFO, $options['verify']);
            }
        }
        if (isset($options['verifyname']) && $options['verifyname'] === false) {
            curl_setopt($this->curl_handle, CURLOPT_SSL_VERIFYHOST, 0);
        }
        $response = curl_exec($this->curl_handle);
        if (false === $response) {
            throw new ClientException('('.curl_errno($this->curl_handle).') '.curl_error($this->curl_handle), ClientException::E_CURL_ERROR);
        }
        $info = curl_getinfo($this->curl_handle);
        $header = '';
        $body = '';
        if ($options['need_header']) {
            $header = substr($response, 0, $info['header_size']);
            $body = substr($response, $info['header_size']);
        } elseif ($options['need_body']) {
            $body = $response;
        }
        return array($header, $body, $info);
    }
}


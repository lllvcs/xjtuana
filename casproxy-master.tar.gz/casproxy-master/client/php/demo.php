<?php

require_once 'CASProxyClient.class.php';

// 初始化自带会话管理器的Client
$c = new CASProxyClientV1SessionContext(
    new CASProxyClientV1('ana.xjtu.edu.cn', '/casproxy', true)
);

// 强制登录
$c->forceLogin();

// 获取登录人userid
var_dump($c->getLoginUser());

// 强制登出
// $c->forceLogout();
package main

import (
	"casproxy/casv1"
	"casproxy/core"
	"casproxy/xjtuws"
	"flag"
	"fmt"
	"log"
	"net/http"
	_ "net/http/pprof"
	"os"
	"strconv"
	"time"
)

var (
	appname    = "CASProxy"
	buildstamp = ""
	githash    = "No githash provided"
	version    = "1.2" // __build_version__
)

func VersionPrinter() {
	var builddate string
	if buildstamp == "" {
		builddate = "No build date provided"
	} else {
		ts, err := strconv.Atoi(buildstamp)
		if err != nil {
			builddate = "No build date provided"
		} else {
			t := time.Unix(int64(ts), 0)
			builddate = t.String()
		}
	}
	fmt.Printf("%v version %v\nGit Hash: %v\nBuild Date: %v\n",
		appname, version, githash, builddate)
	fmt.Println("\nFor more information, run with '-h' option.")
}

func ParseCMDConfig() *core.Config {
	cc := core.NewConfig()
	flag.StringVar(&cc.Host, "host", "localhost", "the casproxy server host")
	flag.IntVar(&cc.Port, "port", 9517, "the casproxy server port")
	flag.StringVar(&cc.ProxyPrefix, "prefix", "", "if you use reverse proxy, use this, eg. https://localhost/casproxy")
	// TODO: TLS support
	//flag.StringVar(&cc.TlsCert, "tlscert", "", "the TLS Cert file")
	//flag.StringVar(&cc.TlsKey, "tlskey", "", "the TLS Key file")
	flag.StringVar(&cc.CASServer, "casServer", "https://cas.xjtu.edu.cn", "the CAS Server's URL")
	flag.IntVar(&cc.CacheItemExpireInternal, "cachetime", 30, "the login GUID will be cached in memory in this duration")
	flag.StringVar(&cc.XjtuUserAuth, "xjtuUserAuth", "", "the Auth param use for xjtuws")
	flag.StringVar(&cc.ImageCacheDir, "imageCacheDir", "", "the user image cache dir, must be writable")
	showVersion := flag.Bool("v", false, "version")
	flag.Parse()
	if *showVersion {
		VersionPrinter()
		os.Exit(0)
	}
	return cc
}

func RegisterRoute() {
	// loaded: net/http/pprof

	// load global route
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		var indexHTML = `
		<html>
		<head>
		<title>%v</title>
		</head>
		<body>
        <h2>%v %v</h2>
        <p>The server is running.</p>
        <hr />
        <p>Copyright &copy; 2017 xczh. All Rights Reserved.</p>
		</body>
		</html>
	`
		w.Write([]byte(fmt.Sprintf(indexHTML, appname, appname, version)))
	})

	// load casv1 route
	fmt.Printf("loding casv1 routes...\n")
	for path, handler := range casv1.Route() {
		fmt.Printf("loaded route: %v\n", path)
		http.HandleFunc(path, handler)
	}
	// load xjtuws route
	fmt.Printf("loding xjtuws routes...\n")
	for path, handler := range xjtuws.Route() {
		fmt.Printf("loaded route: %v\n", path)
		http.HandleFunc(path, handler)
	}
}

func main() {
	// parse config
	cc := ParseCMDConfig()
	// init modules
	if err := casv1.InitConfig(cc); err != nil {
		log.Fatalf("init casv1 config error: %v", err)
	}
	if err := xjtuws.InitConfig(cc); err != nil {
		log.Fatalf("init xjtuws config error: %v", err)
	}

	// init route
	RegisterRoute()

	// run http server
	fmt.Printf("\n%v v%s\n", appname, version)
	log.Printf("listen and server on port %d ...\n", cc.Port)
	log.Printf("access base URL: %v", cc.GetBaseUrl())
	//fmt.Printf("Demo URL:\n\t%v/v1/login?redirect_url=%v/v1/test\n", cc.GetBaseUrl(), cc.GetBaseUrl())
	err := http.ListenAndServe(fmt.Sprintf(":%v", cc.Port), nil)
	if err != nil {
		log.Fatal("[FATAL] HTTP ListenAndServe: ", err)
	}
}

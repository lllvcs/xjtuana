package core

import (
	"fmt"
	"strings"
)

type Config struct {
	// global [must]
	Host string
	// global [optional]
	Port        int
	TlsCert     string
	TlsKey      string
	ProxyPrefix string
	// casv1 [optional]
	CASServer               string
	CacheItemExpireInternal int
	CASService              string
	// xjtuws [optional]
	XjtuUserAuth string
	ImageCacheDir string
}

func NewConfig() *Config {
	return &Config{
		Host:        "localhost",
		Port:        9517,
		TlsCert:     "",
		TlsKey:      "",
		ProxyPrefix: "",
		// casv1
		CASServer:               "https://cas.xjtu.edu.cn",
		CacheItemExpireInternal: 30,
		CASService:              "",
		// xjtuws
		XjtuUserAuth: "",
		ImageCacheDir: "",
	}
}

// current running server's protocol
func (c *Config) GetProtocol() string {
	if c.ProxyPrefix != "" {
		if strings.HasPrefix(c.ProxyPrefix, "https") {
			return "https"
		} else {
			return "http"
		}
	}
	if c.TlsCert != "" && c.TlsKey != "" {
		return "https"
	}
	return "http"
}

// full base url, do not end with '/'
// eg, http://localhost/casproxy
func (c *Config) GetBaseUrl() string {
	if c.ProxyPrefix != "" {
		return c.ProxyPrefix
	}
	port_str := fmt.Sprintf(":%d", c.Port)
	if (c.GetProtocol() == "http" && port_str == ":80") || (c.GetProtocol() == "https" && port_str == ":443") {
		port_str = ""
	}
	return c.GetProtocol() + "://" + c.Host + port_str
}

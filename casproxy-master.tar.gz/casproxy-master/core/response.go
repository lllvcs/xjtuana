package core

import (
	"encoding/json"
	"log"
)

type Response struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

func NewResponseData(data interface{}) *Response {
	return &Response{
		Code:    ERROR_CODE_0,
		Message: ERROR_MSG_0,
		Data:    data,
	}
}

func NewResponseError(code int, msg string) *Response {
	return &Response{
		Code:    code,
		Message: msg,
		Data:    nil,
	}
}

func (r *Response) MustJson() []byte {
	bt, err := json.Marshal(r)
	if err != nil {
		log.Printf("Response json marshal error: %v", err)
		return []byte("unexpected error")
	} else {
		return bt
	}
}

const ERROR_CODE_0 = 0
const ERROR_MSG_0 = "ok"

const ERROR_CODE_50001 = 50001
const ERROR_MSG_50001 = "[casv1][login error]: missing 'redirect_url' param"

const ERROR_CODE_50002 = 50002
const ERROR_MSG_50002 = "[casv1][login error]: 'redirect_url' must start with 'http' or 'https'"

const ERROR_CODE_50003 = 50003
const ERROR_MSG_50003 = "[casv1][vertify error]: missing or invalid 'ticket' param"

const ERROR_CODE_50004 = 50004
const ERROR_MSG_50004 = "[casv1][vertify error]: missing 'redirect_url' cookie"

const ERROR_CODE_50005 = 50005
const ERROR_MSG_50005 = "[casv1][vertify error]: vertify ticket with CAS Server failed"

const ERROR_CODE_50006 = 50006
const ERROR_MSG_50006 = "[casv1][vertify error]: 'redirect_url' error, maybe hacked"

const ERROR_CODE_50100 = 50100
const ERROR_MSG_50100 = "[xjtuws][userinfo]: missing query params"

const ERROR_CODE_50101 = 50101
const ERROR_MSG_50101 = "[xjtuws][userinfo]: remote ws error -> "

const ERROR_CODE_50102 = 50102
const ERROR_MSG_50102 = "[xjtuws][userinfo]: remote ws returned empty result"

const ERROR_CODE_50103 = 50103
const ERROR_MSG_50103 = "[xjtuws][userinfo]: unsupported search key"

const ERROR_CODE_50201 = 50201
const ERROR_MSG_50201 = "[xjtuws][usercard]: missing cardno param"

const ERROR_CODE_50301 = 50301
const ERROR_MSG_50301 = "[xjtuws][userphoto]: missing key or value param"

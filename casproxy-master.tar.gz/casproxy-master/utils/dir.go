package utils

import (
	"log"
	"os"
)

func IsFileExist(file string) bool {
	p, err := os.Stat(file)
	if err != nil {
		return os.IsExist(err)
	} else {
		return !p.IsDir()
	}
}

func IsDirExist(path string) bool {
	p, err := os.Stat(path)
	if err != nil {
		return os.IsExist(err)
	} else {
		return p.IsDir()
	}
}

func CreateDirIfNotExists(path string) error {
	if !IsDirExist(path) {
		err := os.Mkdir(path, 0755)
		if err != nil {
			log.Printf("create dir failed: %s", err)
			return err
		}
	}
	return nil
}

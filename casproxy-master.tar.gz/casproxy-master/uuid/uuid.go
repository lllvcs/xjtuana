package uuid

import (
	"time"
	"os"
	"sync/atomic"
	"encoding/hex"
	"io"
	"fmt"
	"crypto/md5"
	"crypto/rand"
	"encoding/binary"
)

type UUID string

// UUIDCounter is atomically incremented when generating a new UUID
// using NewUUID() function. It's used as a counter part of an id.
var UUIDCounter uint32 = 0

// machineId stores machine id generated once and used in subsequent calls
// to NewObjectId function.
var machineId = readMachineId()

// readMachineId generates machine id and puts it into the machineId global
// variable. If this function fails to get the hostname, it will cause
// a runtime error.
func readMachineId() []byte {
	var sum [3]byte
	id := sum[:]
	hostname, err1 := os.Hostname()
	if err1 != nil {
		_, err2 := io.ReadFull(rand.Reader, id)
		if err2 != nil {
			panic(fmt.Errorf("cannot get hostname: %v; %v", err1, err2))
		}
		return id
	}
	hw := md5.New()
	hw.Write([]byte(hostname))
	copy(id, hw.Sum(nil))
	// fmt.Println("readMachineId:" + string(id))
	return id
}

// NewObjectId returns a new unique ObjectId.
// 4byte time
// 3byte machine ID
// 2byte pid
// 3byte auto increasing ID
func NewUUID() UUID {
	var b [12]byte
	// Timestamp, 4 bytes, big endian
	binary.BigEndian.PutUint32(b[:], uint32(time.Now().Unix()))
	// Machine, first 3 bytes of md5(hostname)
	b[4] = machineId[0]
	b[5] = machineId[1]
	b[6] = machineId[2]
	// Pid, 2 bytes, specs don't specify endianness, but we use big endian.
	pid := os.Getpid()
	b[7] = byte(pid >> 8)
	b[8] = byte(pid)
	// Increment, 3 bytes, big endian
	i := atomic.AddUint32(&UUIDCounter, 1)
	b[9] = byte(i >> 16)
	b[10] = byte(i >> 8)
	b[11] = byte(i)
	return UUID(b[:])
}

// Hex returns a hex representation of the UUID.
func (id UUID) Hex() string {
	return hex.EncodeToString([]byte(id))
}
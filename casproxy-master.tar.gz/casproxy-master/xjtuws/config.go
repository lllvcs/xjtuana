package xjtuws

import (
	"casproxy/core"
	"casproxy/utils"
)

type Config struct {
	XjtuUserAuth  string
	ImageCacheDir string
}

var config = &Config{}

func InitConfig(cc *core.Config) (err error) {
	config.XjtuUserAuth = cc.XjtuUserAuth
	if cc.ImageCacheDir != "" {
		err = utils.CreateDirIfNotExists(cc.ImageCacheDir)
		if err != nil {
			return err
		}
		config.ImageCacheDir = cc.ImageCacheDir
	}
	return nil
}

package xjtuws

const PATH_USERINFO = "/xjtuws/userinfo"

const PATH_USERCARD = "/xjtuws/usercard"

const PATH_USERPHOTO = "/xjtuws/userphoto"

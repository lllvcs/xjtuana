package xjtuws

import (
	"casproxy/utils"
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
)

type UserInfoCardDto struct {
	Cardno       string
	Userno       string
	Username     string
	Dormid       string
	Roomid       string
	Dormname     string
	Dep          string
	UsertypeName string
	ImageUrl     string
}

func GetInfoByCardno(cardno string) (*UserInfoCardDto, error) {
	const LX_XJTU_URL = "http://lx.xjtu.edu.cn:8280/cardsignin/terminal"
	post_data := "card_num=" + cardno
	client := utils.NewHTTPClient()
	req, err := http.NewRequest(
		"POST",
		LX_XJTU_URL,
		strings.NewReader(post_data))
	if err != nil {
		log.Printf("create http request error: %s", err)
		return nil, err
	}
	// set headers
	req.Header.Set("Accept-Language", "zh-CN,zh;q=0.8,zh-TW;q=0.6,en;q=0.4")
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Origin", "http://lx.xjtu.edu.cn:8280")
	req.Header.Set("Referer", "http://lx.xjtu.edu.cn:8280/cardsignin/terminal")
	// send http request
	res, err := client.Do(req)
	if err != nil {
		log.Printf("read from res.Body error: %s", err)
		return nil, err
	}
	defer res.Body.Close()
	//body, err := ioutil.ReadAll(res.Body)
	//utfBody, err := iconv.NewReader(res.Body, charset, "utf-8")
	page, err := goquery.NewDocumentFromReader(res.Body)
	if err != nil {
		log.Printf("parse html page error: %s", err)
		return nil, err
	}
	page_corner := page.Find("#corner")
	img_url_temp, exist := page_corner.Find("img").Attr("src")
	img_url := "http://lx.xjtu.edu.cn:8280" + strings.Split(img_url_temp, ";")[0]

	if !exist {
		// 用户不存在
		return nil, fmt.Errorf("the cardno is not exist")
	}
	pUser := &UserInfoCardDto{}

	trs := page_corner.Find("table tr")
	for i := 0; i < trs.Length(); i++ {
		title := trs.Eq(i).Find("th").Text()
		value := trs.Eq(i).Find("td").Text()
		switch title {
		case "学号/职工号":
			pUser.Userno = value
		case "姓名":
			pUser.Username = value
		case "宿舍楼号":
			pUser.Dormid = value
		case "房间号":
			pUser.Roomid = value
		case "书院":
			pUser.Dormname = value
		case "学院/工作部门":
			pUser.Dep = value
		case "人员类别":
			pUser.UsertypeName = value
		default:
			log.Printf("[xjtuws][usercard]unknown title:%s, value:%s", title, value)
		}
	}
	// 下载用户照片
	go fetchUserPhotoByUrl(img_url, pUser.Userno)
	// 设置卡号
	pUser.Cardno = cardno
	pUser.ImageUrl = img_url
	return pUser, nil
}

func fetchUserPhotoByUrl(url string, userno string) error {
	if config.ImageCacheDir == "" {
		return nil
	}
	// 图片存放目录
	filepath := config.ImageCacheDir + "/" + userno + ".jpg"
	if utils.IsFileExist(filepath) {
		return nil
	}
	res, err := http.Get(url)
	defer res.Body.Close()
	if err != nil {
		log.Printf("read from res.Body error: %s", err)
		return err
	}
	f, err := os.Create(filepath)
	defer f.Close()
	if err != nil {
		log.Printf("create image file failed: %s", err)
		return err
	}
	//bs, err := io.Copy(f, res.Body)
	_, err = io.Copy(f, res.Body)
	if err != nil {
		log.Printf("download image file failed: %s", err)
		return err
	}
	// log.Printf("download user image file ok: %s(%d KB)", filename, bs/1024)
	return nil
}

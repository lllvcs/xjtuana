package xjtuws

import (
	"encoding/xml"
)

/***** 用户信息服务   *****/

type UserInfoPortType struct {
	client *SOAPClient
}

func NewUserInfoPortType() *UserInfoPortType {
	url := "http://u.xjtu.edu.cn/axis2/services/UserInfo"
	tls := false
	auth := &BasicAuth{}
	client := NewSOAPClient(url, tls, auth)

	return &UserInfoPortType{
		client: client,
	}
}

// 基本信息服务
type SimpleInfoDto struct {
	XMLName xml.Name `xml:"return"`

	Classid  string `xml:"classid,omitempty"`
	Dep      string `xml:"dep,omitempty"`
	Depid    string `xml:"depid,omitempty"`
	Userid   string `xml:"userid,omitempty"`
	Username string `xml:"username,omitempty"`
	Userno   string `xml:"userno,omitempty"`
	Usertype string `xml:"usertype,omitempty"`
}

// 基本信息：根据userid(NetID)获取
type GetSimpleInfoById struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getSimpleInfoById"`

	Limited string `xml:"limited,omitempty"`
	Uid     string `xml:"uid,omitempty"`
}

type GetSimpleInfoByIdResponse struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getSimpleInfoByIdResponse"`

	Return_ *SimpleInfoDto `xml:"return,omitempty"`
}

func (service *UserInfoPortType) GetSimpleInfoById(request *GetSimpleInfoById) (*GetSimpleInfoByIdResponse, error) {
	response := new(GetSimpleInfoByIdResponse)
	err := service.client.Call("urn:getSimpleInfoById", request, response)
	if err != nil {
		return nil, err
	}

	return response, nil
}

// 详细信息服务

type UserInfoDto struct {
	XMLName xml.Name `xml:"return" json:"-"`

	Birthday        string `xml:"birthday,omitempty"`
	Classid         string `xml:"classid,omitempty"`
	Dep             string `xml:"dep,omitempty"`
	Depid           string `xml:"depid,omitempty"`
	Email           string `xml:"email,omitempty"`
	Gender          string `xml:"gender,omitempty"`
	Idcardname      string `xml:"idcardname,omitempty"`
	Idcardno        string `xml:"idcardno,omitempty"`
	Marriage        string `xml:"marriage,omitempty"`
	Mobile          string `xml:"mobile,omitempty"`
	Nation          string `xml:"nation,omitempty"`
	Nationplace     string `xml:"nationplace,omitempty"`
	Polity          string `xml:"polity,omitempty"`
	Roomnumber      string `xml:"roomnumber,omitempty"`
	Roomphone       string `xml:"roomphone,omitempty"`
	Speciality      string `xml:"speciality,omitempty"`
	Studenttype     string `xml:"studenttype,omitempty"`
	Tutoremployeeid string `xml:"tutoremployeeid,omitempty"`
	Userid          string `xml:"userid,omitempty"`
	Username        string `xml:"username,omitempty"`
	Userno          string `xml:"userno,omitempty"`
	Usertype        string `xml:"usertype,omitempty"`
}

// 详细信息：根据userid(NetID)获取
type GetInfoById struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoById"`

	Auth string `xml:"auth,omitempty"`
	Uid  string `xml:"uid,omitempty"`
}

type GetInfoByIdResponse struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByIdResponse"`

	Return_ *UserInfoDto `xml:"return,omitempty"`
}

func (service *UserInfoPortType) GetInfoById(request *GetInfoById) (*GetInfoByIdResponse, error) {
	response := new(GetInfoByIdResponse)
	err := service.client.Call("urn:getInfoById", request, response)
	if err != nil {
		return nil, err
	}

	return response, nil
}

// 详细信息：根据学号获取

type GetInfoByNo struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByNo"`

	Auth string `xml:"auth,omitempty"`
	Sno  string `xml:"sno,omitempty"`
}

type GetInfoByNoResponse struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByNoResponse"`

	Return_ *UserInfoDto `xml:"return,omitempty"`
}

func (service *UserInfoPortType) GetInfoByNo(request *GetInfoByNo) (*GetInfoByNoResponse, error) {
	response := new(GetInfoByNoResponse)
	err := service.client.Call("urn:getInfoByNo", request, response)
	if err != nil {
		return nil, err
	}

	return response, nil
}

// 详细信息：根据手机号获取

type GetInfoByMobile struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByMobile"`

	Auth   string `xml:"auth,omitempty"`
	Mobile string `xml:"mobile,omitempty"`
}

type GetInfoByMobileResponse struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByMobileResponse"`

	Return_ []*UserInfoDto `xml:"return,omitempty"`
}

func (service *UserInfoPortType) GetInfoByMobile(request *GetInfoByMobile) (*GetInfoByMobileResponse, error) {
	response := new(GetInfoByMobileResponse)
	err := service.client.Call("urn:getInfoByMobile", request, response)
	if err != nil {
		return nil, err
	}

	return response, nil
}

// 详细信息：根据姓名获取
type GetInfoByName struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByName"`

	Auth  string `xml:"auth,omitempty"`
	Sname string `xml:"sname,omitempty"`
}

type GetInfoByNameResponse struct {
	XMLName xml.Name `xml:"http://info.webservice.xjtu/xsd getInfoByNameResponse"`

	Return_ []*UserInfoDto `xml:"return,omitempty"`
}

func (service *UserInfoPortType) GetInfoByName(request *GetInfoByName) (*GetInfoByNameResponse, error) {
	response := new(GetInfoByNameResponse)
	err := service.client.Call("urn:getInfoByName", request, response)
	if err != nil {
		return nil, err
	}

	return response, nil
}

func GetInfoByUserid(userid string) (*UserInfoDto, error) {
	ws := NewUserInfoPortType()
	resp, err := ws.GetInfoById(&GetInfoById{
		Auth: config.XjtuUserAuth,
		Uid:  userid,
	})
	if err != nil {
		// webservice 查询失败
		return nil, err
	}
	if resp.Return_.Userid != userid {
		// 未查询到
		return nil, nil
	}
	return resp.Return_, nil
}

package xjtuws

import (
	"encoding/base64"
	"casproxy/utils"
	"encoding/xml"
	"fmt"
	"io/ioutil"
	"log"
	"os"
)

/***** 用户照片服务   *****/

type UserPhotoPortType struct {
	client *SOAPClient
}

func NewUserPhotoPortType() *UserPhotoPortType {
	url := "http://u.xjtu.edu.cn/axis2/services/UserPhoto"
	tls := false
	auth := &BasicAuth{}
	client := NewSOAPClient(url, tls, auth)

	return &UserPhotoPortType{
		client: client,
	}
}

// 根据学号获取
type GetPhotoByNo struct {
	XMLName xml.Name `xml:"http://photo.webservice.xjtu/xsd getPhotoByNo"`

	Auth string `xml:"auth,omitempty"`
	Sno  string `xml:"sno,omitempty"`
}

type GetPhotoByNoResponse struct {
	XMLName xml.Name `xml:"http://photo.webservice.xjtu/xsd getPhotoByNoResponse"`

	Return_ []byte `xml:"return,omitempty"` // 照片的base64编码byte
}

func (service *UserPhotoPortType) GetPhotoByNo(request *GetPhotoByNo) (*GetPhotoByNoResponse, error) {
	response := new(GetPhotoByNoResponse)
	err := service.client.Call("urn:getPhotoByNo", request, response)
	if err != nil {
		return nil, err
	}

	return response, nil
}

type UserphotoDto struct {
	Userno      string
	ImageB64Str string
}

func GetPhotoByUserno(userno string) ([]byte, error) {
	fname := config.ImageCacheDir + "/" + userno + ".jpg"
	imgFileBytes, err := ioutil.ReadFile(fname)
	if err == nil {
		// 返回Photo文件base64 encode bytes
		buf := make([]byte, base64.StdEncoding.EncodedLen(len(imgFileBytes)))
		base64.StdEncoding.Encode(buf, imgFileBytes)
		return buf, nil
	}
	// 文件不存在时查询web service
	ws := NewUserPhotoPortType()
	resp, err := ws.GetPhotoByNo(&GetPhotoByNo{
		Auth: config.XjtuUserAuth,
		Sno:  userno,
	})
	if err != nil {
		return nil, err
	}
	imgB64Bytes := resp.Return_
	go func() {
		if config.ImageCacheDir == "" {
			return
		}
		// 图片存放目录
		filepath := config.ImageCacheDir + "/" + userno + ".jpg"
		if utils.IsFileExist(filepath) {
			return
		}
		// 写入图像文件
		imgFileBytes := make([]byte, base64.StdEncoding.DecodedLen(len(imgB64Bytes)))
		_, err := base64.StdEncoding.Decode(imgFileBytes, imgB64Bytes)
		if err != nil {
			errmsg := fmt.Sprintf("UserPhoto base64 decode error (%s)", err)
			log.Print(errmsg)
			return
		}
		if len(imgFileBytes) == 0 {
			// empty result
			return
		}
		f, err := os.Create(filepath)
		defer f.Close()
		if err != nil {
			log.Printf("create image file failed: %s", err)
			return
		}
		_, err = f.Write(imgFileBytes)
		if err != nil {
			log.Printf("Write bytes to image file failed: %s", err)
			return
		}
	}()
	// Image base64 encode
	return imgB64Bytes, nil
}

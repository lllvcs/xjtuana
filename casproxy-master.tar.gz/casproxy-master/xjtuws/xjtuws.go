package xjtuws

import (
	"casproxy/core"
	"fmt"
	"log"
	"net/http"
	// "strconv"
)

var successCounter uint64
var failedCounter uint64
var errorCounter uint64

func Route() map[string]func(http.ResponseWriter, *http.Request) {
	return map[string]func(http.ResponseWriter, *http.Request){
		PATH_USERINFO:  UserinfoHandler,
		PATH_USERCARD:  UsercardHandler,
		PATH_USERPHOTO: UserphotoHandler,
	}
}

func UserinfoHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	key := query.Get("key")
	value := query.Get("value")
	// 最大内部http请求次数
	/*
		max_redirect := -1
		if mr := query.Get("max_redirect"); mr != "" {
			mr, err := strconv.Atoi(mr)
			if err == nil {
				max_redirect = mr
			}
		}
	*/
	if key == "" || value == "" {
		// request error, missing 'key' or 'value' param
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50100,
			core.ERROR_MSG_50100,
		).MustJson())
		return
	}
	ws := NewUserInfoPortType()
	switch key {
	case "userid":
		resp, err := ws.GetInfoById(&GetInfoById{
			Auth: config.XjtuUserAuth,
			Uid:  value,
		})
		if err != nil {
			// webservice 查询失败
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50101,
				core.ERROR_MSG_50101+err.Error(),
			).MustJson())
			return
		}
		if resp.Return_.Userid != value {
			// 未查询到
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50102,
				core.ERROR_MSG_50102,
			).MustJson())
			return
		}
		w.Write(core.NewResponseData(resp.Return_).MustJson())
	case "userno":
		resp, err := ws.GetInfoByNo(&GetInfoByNo{
			Auth: config.XjtuUserAuth,
			Sno:  value,
		})
		if err != nil {
			// webservice 查询失败
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50101,
				core.ERROR_MSG_50101+err.Error(),
			).MustJson())
			return
		}
		if resp.Return_.Userno != value {
			// 未查询到
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50102,
				core.ERROR_MSG_50102,
			).MustJson())
			return
		}
		w.Write(core.NewResponseData(resp.Return_).MustJson())
	case "username":
		resp, err := ws.GetInfoByName(&GetInfoByName{
			Auth:  config.XjtuUserAuth,
			Sname: value,
		})
		if err != nil {
			// webservice 查询失败
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50101,
				core.ERROR_MSG_50101+err.Error(),
			).MustJson())
			return
		}
		if len(resp.Return_) == 0 {
			// 空查询结果
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50102,
				core.ERROR_MSG_50102,
			).MustJson())
			return
		}
		w.Write(core.NewResponseData(resp.Return_).MustJson())
	case "mobile":
		resp, err := ws.GetInfoByMobile(&GetInfoByMobile{
			Auth:   config.XjtuUserAuth,
			Mobile: value,
		})
		if err != nil {
			// webservice 查询失败
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50101,
				core.ERROR_MSG_50101+err.Error(),
			).MustJson())
			return
		}
		if len(resp.Return_) == 0 {
			// 空查询结果
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50102,
				core.ERROR_MSG_50102,
			).MustJson())
			return
		}
		w.Write(core.NewResponseData(resp.Return_).MustJson())
	default:
		errmsg := fmt.Sprintf("unsupport search key: %s", key)
		log.Println(errmsg)
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50103,
			errmsg,
		).MustJson())
	}
}

func UsercardHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	cardno := query.Get("cardno")
	if cardno == "" {
		// request error, missing 'cardno' param
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50201,
			core.ERROR_MSG_50201,
		).MustJson())
		return
	}
	pUserDto, err := GetInfoByCardno(cardno)
	if err != nil {
		// 查询失败
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50101,
			core.ERROR_MSG_50101+err.Error(),
		).MustJson())
		return
	}
	if pUserDto == nil {
		// 空查询结果
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50102,
			core.ERROR_MSG_50102,
		).MustJson())
		return
	}
	w.Write(core.NewResponseData(*pUserDto).MustJson())
}

func UserphotoHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	key := query.Get("key")
	value := query.Get("value")
	if key == "" || value == "" {
		// request error, missing 'key' or 'value' param
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50301,
			core.ERROR_MSG_50301,
		).MustJson())
		return
	}
	switch key {
	case "userno":
		imgB64Bytes, err := GetPhotoByUserno(value)
		if err != nil {
			// 查询失败
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50101,
				core.ERROR_MSG_50101+err.Error(),
			).MustJson())
			return
		}
		if len(imgB64Bytes) == 0 {
			// 空查询结果
			w.Write(core.NewResponseError(
				core.ERROR_CODE_50102,
				core.ERROR_MSG_50102,
			).MustJson())
			return
		}
		w.Write(core.NewResponseData(UserphotoDto{
			Userno:      value,
			ImageB64Str: string(imgB64Bytes),
		}).MustJson())
	default:
		errmsg := fmt.Sprintf("unsupport search key: %s", key)
		log.Println(errmsg)
		w.Write(core.NewResponseError(
			core.ERROR_CODE_50103,
			errmsg,
		).MustJson())
	}
}

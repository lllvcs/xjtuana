#### **社团公邮**

账号1：`xjtuana@126.com`

密码：`xjtuana2017`

账号2: `xjtuanapub@163.com`

密码：`xjtuana@163`

---
#### **百度云会员**

账号：`西交学生网络`

密码：`xjtuana@baidu`

*注：临时上传的文件放临时文件夹，长期保存的放个人文件夹，勿过多占用*

---
#### **优酷会员**

账号：`xjtuana@126.com`

密码：`xjtuana2017`

---
#### **腾讯视频会员**

账号：`3600810244`

密码：`xjtuana@qq`

---
#### **Bilibili大会员**

用户名：`xjtuanapub@163.com`

密码：`xjtuana@bilibili`

---
#### Jetbrains激活服务

介绍：捷克斯洛伐克的一家开发各类IDE的公司

官网： www.jetbrains.com

提供C/C++/Java/Golang/Python/PHP/Ruby/R/Web前端/Swift/Objective C等语言的IDE，以及.Net框架下的开发工具和Visual Studio的增强调试工具，研发部的同学们做开发可能需要。

激活服务器：https://jetbrains.as.xjtuana.com/
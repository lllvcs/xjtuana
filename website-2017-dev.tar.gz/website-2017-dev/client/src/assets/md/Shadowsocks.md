#### Socks5代理服务

Socks5代理采用的客户端为Shadowsocks，你可以在你的电脑上运行Shadowsocks客户端即可启用Socks5代理。

**客户端下载地址**

- Windows版 https://github.com/shadowsocks/shadowsocks-windows/releases/latest
- MacOS版  https://github.com/shadowsocks/ShadowsocksX-NG/releases/latest
- Android版 https://github.com/shadowsocks/shadowsocks-android/releases/latest
- IOS版 Apple Store搜索Shadowrocket

**校内代理（在校外下论文）**

- 服务器地址：`xjtu.proxy.xjtuana.com`
- 服务器端口：`6011`
- 连接密码：`ana2018`
- 加密方式：`AES-256-GCM`

上述连接参数可能会不定期更换，会在工作群通知大家，请再次查看本页面填写更新后的参数。
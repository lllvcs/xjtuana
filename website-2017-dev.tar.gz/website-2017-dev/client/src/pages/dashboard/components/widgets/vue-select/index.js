import VueSelect from './components/Select.vue'
import mixins from './mixins/index'

export default VueSelect
export { VueSelect, mixins }

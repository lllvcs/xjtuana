import axios from './axios'
import VeeValidate from './vee-validate'

export {
  axios,
  VeeValidate,
}

<template>
  <footer class="weui-msg__extra-area">
    <div class="weui-footer">
      <p class="weui-footer__links">
        <a href="https://ana.xjtu.edu.cn" class="weui-footer__link">西交网管会</a>
      </p>

      <p class="weui-footer__text">Copyright &copy; 2014-2017 XJTUANA</p>
    </div>
  </footer>
</template>

<script>
export default {}
</script>

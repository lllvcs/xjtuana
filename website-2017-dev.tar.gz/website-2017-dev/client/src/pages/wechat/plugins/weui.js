import weui from 'weui.js'

export default weui

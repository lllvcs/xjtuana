<template>
<div>
  <PageHeader />
</div>
</template>

<script>
import PageHeader from '@/pages/wechat/components/PageHeader'
export default {
  components: {
    PageHeader,
  },
}
</script>

import axios from './axios'
import swal from './swal'
import moment from './moment'

export {
  axios,
  swal,
  moment,
}

import moment from 'moment'
moment.locale('zh-cn')

export default moment

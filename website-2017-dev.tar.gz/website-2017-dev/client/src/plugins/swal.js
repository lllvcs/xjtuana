import swal from 'sweetalert2'
swal.setDefaults({
  confirmButtonText: '确认',
  cancelButtonText: '取消',
})

export default swal

<?php

return [
    'title' => '    FAQ',
    'FAQ' => 'FAQ',
    'Asked' => 'Frequently Asked Questions',
    'line_1' => 'No solution? Click on support!',
    'line_2' => 'Network Support',
    'index' => 'Index',
    'footer' => 'Last updated: ',
];
<?php

return [
    'line_1' => 'Scan to follow XJTUANA on WeChat',
];
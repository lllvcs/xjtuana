<?php

return [
    'home' => 'Home',
    'faq' => 'FAQ',
    'support' => 'Network Support',
    "dashboard" => 'Dashboard',
    'logout' => "Logout",
    'login' => "Login",
];
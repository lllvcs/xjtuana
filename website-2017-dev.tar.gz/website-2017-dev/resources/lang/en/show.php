<?php

return [
    'title' => 'Suppoet Details',
    'head' => 'Suppoet Details',
];
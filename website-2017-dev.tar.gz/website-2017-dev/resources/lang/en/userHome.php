<?php

return [
    'title' => 'User Center',
    'head' => 'User Center',
    'function_1' => 'Function of Societies',
    'function_2' => 'New Support',
    'function_3' => 'All Support',
    'function_4' => 'Join us',
    'support_1' => 'Record of Support',
    'support_2' => 'No record of Support ^_^',
    'support_3' => 'Support number',
    'support_4' => 'Support time',
    'support_5' => 'Hostel No.',
    'support_6' => 'state',
    'support_7' => 'Operation',
    'show' => 'show',
    'link' => 'Blogroll',
];
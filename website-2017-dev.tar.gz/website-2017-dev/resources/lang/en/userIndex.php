<?php

return [
    'title' => 'All Support',
    'head' => 'All Support',
    'history' => 'Support History',
    'isEmpty' => 'No record of Support ^_^',
    'line_1' => 'Support number',
    'line_2' => 'Date of Support',
    'line_3' => 'Hostel No.',
    'line_4' => 'State',
    'line_5' => 'Processing administrator',
    'line_6' => 'Operation',
    'line_7' => 'Show',
];
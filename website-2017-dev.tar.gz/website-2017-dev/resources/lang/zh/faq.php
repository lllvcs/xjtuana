<?php

return [
    'title' => '    FAQ',
    'FAQ' => 'FAQ',
    'Asked' => 'Frequently Asked Questions - 常见问题解答',
    'line_1' => '没有解决？点击报修！',
    'line_2' => '网络报修',
    'index' => '目录',
    'footer' => '最后更新于：',
];
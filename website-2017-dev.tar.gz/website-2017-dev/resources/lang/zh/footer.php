<?php

return [
    'line_1' => '扫码关注微信平台：XJTUANA',
];
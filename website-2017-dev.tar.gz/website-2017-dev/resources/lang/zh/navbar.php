<?php

return [
    'home' => '社团首页',
    'faq' => '常见问题',
    'support' => '网络报修',
    "dashboard" => '控制台',
    'logout' => "注销",
    'login' => "登录",
];
<?php

return [
    'title' => '报修详情',
    'head' => '报修详情',
];
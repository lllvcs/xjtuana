<?php

return [
    'title' => '用户中心',
    'head' => '用户中心',
    'function_1' => '社团功能',
    'function_2' => '新的报修',
    'function_3' => '全部报修',
    'function_4' => '加入我们',
    'support_1' => '报修记录',
    'support_2' => '暂无报修记录 ^_^',
    'support_3' => '报修号',
    'support_4' => '报修时间',
    'support_5' => '宿舍号',
    'support_6' => '状态',
    'support_7' => '操作',
    'show' => '查看',
    'link' => '友情链接',
];
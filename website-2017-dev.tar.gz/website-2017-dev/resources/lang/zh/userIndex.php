<?php

return [
    'title' => '全部报修',
    'head' => '全部报修',
    'history' => '报修历史',
    'isEmpty' => '暂无报修记录 ^_^',
    'line_1' => '报修号',
    'line_2' => '报修日期',
    'line_3' => '宿舍号',
    'line_4' => '状态',
    'line_5' => '处理网管',
    'line_6' => '操作',
    'line_7' => '查看',
];
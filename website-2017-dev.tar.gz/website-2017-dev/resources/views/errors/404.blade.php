@extends('errors.default')

@section('title', '页面不存在')

@section('message')
访问的页面不存在
@endsection
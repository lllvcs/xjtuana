@extends('errors.default')

@section('title', '页面过期')

@section('message')
页面已过期，请返回后重试
@endsection
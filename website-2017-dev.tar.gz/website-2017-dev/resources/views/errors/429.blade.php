@extends('errors.default')

@section('message')
请求过于频繁
@endsection
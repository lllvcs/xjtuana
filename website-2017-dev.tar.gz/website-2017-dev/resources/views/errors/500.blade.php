@extends('errors.default')

@section('message')
服务器错误，请稍候再试
@endsection
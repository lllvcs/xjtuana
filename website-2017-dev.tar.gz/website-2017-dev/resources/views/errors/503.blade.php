@extends('errors.default')

@section('links')
@endsection
@section('top-links')
@endsection

@section('title', '维护中')

@section('message')
服务器维护中...
@endsection
<nav class="toolbar visible-xs">
    <a href="/{{App::getLocale()}}/user/">
        <button class="button button-block button-plain button-raised" title="个人中心">
            <i class="fa fa-fw fa-1x fa-user"></i>
            {{-- <i class="fa fa-fw fa-1x fa-wrench"></i> --}}
        </button>
    </a>

    <a href="#">
        <button class="button button-block button-plain button-raised" title="返回顶部">
            <i class="fa fa-fw fa-1x fa-arrow-up"></i>
        </button>
    </a>
</nav>
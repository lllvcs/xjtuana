<?php

namespace Xjtuana\XjtuApi\Api;

class XjtuApiException extends \Exception {}

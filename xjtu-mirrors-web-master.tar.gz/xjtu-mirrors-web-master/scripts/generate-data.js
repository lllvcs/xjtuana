'use strict'
const path = require('path')
const utils = require('./utils')
const glob = require('glob')
const fs = require('fs')
const chokidar = require('chokidar')

const helpSource = 'static/md/help/*.md'
const helpDest = 'src/store/data/helps.json'
const newsSource = 'static/md/news/*.md'
const newsDest = 'src/store/data/news.json'

module.exports = function (watch = false) {
  if (watch === true) {
    chokidar.watch(helpSource).on('all', () => {
      generateHelps(helpSource, helpDest)
    })
    chokidar.watch(newsSource).on('all', () => {
      generateNews(newsSource, newsDest)
    })
  } else {
    generateHelps(helpSource, helpDest)
    generateNews(newsSource, newsDest)
  }
}

function generateHelps (source, dest) {
  let helps = glob.sync(utils.path.root(source)).map(item => path.basename(item, '.md')).filter(item => item !== 'index')
  helps.sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()))
  fs.writeFileSync(utils.path.root(dest), JSON.stringify(helps))
}

function generateNews (source, dest) {
  let newsPath = glob.sync(utils.path.root(source))
  let news = []
  for (let n of newsPath) {
    let name = path.basename(n, '.md')
    let content = fs.readFileSync(n, 'utf8').match(/# (.*)(\r)?\n.*> (\d{4}-\d{2}-\d{2})/)
    let title = content[1]
    let date = content[3]
    news.push({
      name,
      title,
      date
    })
  }
  news.sort((a, b) => Date.parse(a.date) < Date.parse(b.date))
  fs.writeFileSync(utils.path.root(dest), JSON.stringify(news))
}

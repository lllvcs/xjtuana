const utils = require('../utils')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const WebpackBar = require('webpackbar')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')

const webpackBaseConfig = {
  context: utils.path.root(),
  entry: {
    'app': './src/main.js',
    'vendor.bs': ['bootstrap', 'jquery', 'popper.js'] 
  },
  output: {
    path: utils.path.dist(),
    filename: '[name].js',
    publicPath: '/'
  },
  resolve: {
    extensions: ['.js', '.vue', '.json'],
    alias: {
      '@': utils.path.src(),
      'vue$': 'vue/dist/vue.esm.js'
    }
  },
  module: {
    rules: [
      {
        enforce: 'pre',
        test: /\.(js|vue)$/,
        loader: 'eslint-loader',
        exclude: /node_modules/,
        options: {
          fix: true
        }
      },

      {
        test: /\.vue$/,
        loader: 'vue-loader'
      },

      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'babel-loader'
      },

      {
        test: /\.css$/,
        use: [
          ...utils.useCommonStyleLoaders()
        ]
      },

      {
        test: /\.scss$/,
        use: [
          ...utils.useCommonStyleLoaders(),
          'sass-loader'
        ]
      },

      {
        test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/i,
        loader: 'url-loader',
        options: {
          limit: 10000,
          name: utils.path.assets('fonts/[name].[hash:7].[ext]')
        }
      },

      {
        test: /\.(png|jpe?g|gif)(\?.*)?$/,
        loader: 'url-loader',
        options: {
          limit: 10000,
          name: utils.path.assets('img/[name].[hash:7].[ext]')
        }
      },

      {
        test: /\.(svg)(\?.*)?$/,
        loader: 'file-loader',
        options: {
          name: utils.path.assets('img/[name].[hash:7].[ext]')
        }
      }
    ]
  },
  plugins: [
    // Necessary for vue-loader v15+
    new VueLoaderPlugin(),

    new WebpackBar({
      color: 'blue',
      compiledIn: false
    }),

    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: utils.path.src('index.html'),
      inject: true
    }),

    new CopyWebpackPlugin([
      {
        from: utils.path.root('static'),
        to: utils.path.assets(),
        ignore: ['.*']
      }
    ])
  ],
  node: {
    setImmediate: false,
    global: false,
    process: false,
    dgram: 'empty',
    fs: 'empty',
    net: 'empty',
    tls: 'empty',
    child_process: 'empty'
  }
}

module.exports = webpackBaseConfig

const webpackMerge = require('webpack-merge')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin')

const utils = require('../utils')
const webpackBaseConfig = require('./base.conf')

require('../generate-data')(true)

const webpackBuildConfig = webpackMerge(webpackBaseConfig, {
  mode: 'production',
  devtool: false,
  output: {
    path: utils.path.dist(),
    filename: utils.path.assets('js/[name].[chunkhash:8].js'),
    publicPath: '/'
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: utils.path.assets('css/[name].[contenthash].css')
    }),

    new OptimizeCssAssetsPlugin({
      canPrint: false,
      cssProcessorOptions: {
        autoprefixer: { disable: true },
        mergeLonghand: false
      }
    })
  ],
  optimization: {
    splitChunks: {
      cacheGroups: {
        vue: {
          test: /[\\/]node_modules[\\/](vue|vuex|vue-router)[\\/]/,
          name: 'vendor.vue',
          chunks: 'all'
        },
        commons: {
          test: /[\\/]node_modules[\\/]/,
          priority: -10,
          name: 'vendor.commons',
          chunks: 'all'
        }
      }
    }
  }
})

module.exports = webpackBuildConfig

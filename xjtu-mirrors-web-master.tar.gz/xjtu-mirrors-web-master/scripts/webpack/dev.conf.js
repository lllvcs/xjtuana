const utils = require('../utils')
const portfinder = require('portfinder')
const webpack = require('webpack')
const webpackMerge = require('webpack-merge')
const webpackBaseConfig = require('./base.conf')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const FriendlyErrorsPlugin = require('friendly-errors-webpack-plugin')

require('../generate-data')(true)

const webpackDevConfig = webpackMerge(webpackBaseConfig, {
  mode: 'development',
  devtool: 'cheap-module-eval-source-map',
  devServer: {
    historyApiFallback: {
      rewrites: [
        { from: /.*/, to: '/index.html' }
      ]
    },
    hot: true,
    contentBase: false,
    compress: true,
    host: process.platform === 'win32' ? 'localhost' : '0.0.0.0',
    port: 8000,
    overlay: { warnings: false, errors: true },
    quiet: true
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: utils.path.src('index.html'),
      inject: true
    }),
    new CopyWebpackPlugin([
      {
        from: utils.path.root('static'),
        to: utils.path.assets(),
        ignore: ['.*']
      }
    ])
  ]
})

module.exports = new Promise((resolve, reject) => {
  portfinder.basePort = webpackDevConfig.devServer.port
  portfinder.getPort((err, port) => {
    if (err) {
      reject(err)
    } else {
      webpackDevConfig.devServer.port = port
      webpackDevConfig.plugins.push(new FriendlyErrorsPlugin({
        compilationSuccessInfo: {
          messages: [`Webpack dev server listening: http://${webpackDevConfig.devServer.host}:${port}`]
        }
      }))
      resolve(webpackDevConfig)
    }
  })
})

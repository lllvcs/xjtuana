<template>
  <div id="app">
    <TheHeader />

    <TheMain />

    <TheFooter />
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import TheHeader from '@/components/layouts/TheHeader'
import TheMain from '@/components/layouts/TheMain'
import TheFooter from '@/components/layouts/TheFooter'
export default {
  name: 'App',
  components: {
    TheHeader,
    TheMain,
    TheFooter
  },
  methods: {
    ...mapActions([
      'fetchMirrors'
    ])
  },
  created () {
    this.fetchMirrors()
    setInterval(this.fetchMirrors, 30 * 1000)
  }
}
</script>

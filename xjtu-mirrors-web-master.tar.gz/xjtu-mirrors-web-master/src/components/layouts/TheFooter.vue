<template>
  <footer class="text-center bg-dark text-white p-3 animated fadeIn">
    <p class="my-2">西安交通大学软件镜像站</p>

    <p class="my-2">Copyright &copy; 2018 XJTUANA. All Rights Reserved.</p>
  </footer>
</template>

<script>
export default {
  name: 'TheFooter'
}
</script>

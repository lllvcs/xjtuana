<template>
  <nav class="navbar navbar-expand-sm navbar-dark bg-transparent">
    <!--container-->
    <div class="container">

      <!--LOGO-->
      <router-link
        to="/"
        class="navbar-brand d-inline d-sm-none"
      >
        <span class="animated fadeIn">XJTU Mirrors</span>
      </router-link>

      <!--expand button-->
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"/>
      </button>

      <!--collapse links-->
      <div
        id="navbarSupportedContent"
        class="collapse navbar-collapse"
      >
        <ul class="navbar-nav ml-auto text-center">
          <router-link
            to="/"
            tag="li"
            class="nav-item animated fadeInLeft"
            style="animation-delay: .3s;"
            exact
          >
            <a class="nav-link">Home</a>
          </router-link>

          <router-link
            to="/news"
            tag="li"
            class="nav-item animated fadeInLeft"
            style="animation-delay: .4s;"
          >
            <a class="nav-link">News</a>
          </router-link>

          <router-link
            to="/help"
            tag="li"
            class="nav-item animated fadeInLeft"
            style="animation-delay: .5s;"
          >
            <a class="nav-link">Help</a>
          </router-link>

          <router-link
            to="/about"
            tag="li"
            class="nav-item animated fadeInLeft"
            style="animation-delay: .6s;"
          >
            <a class="nav-link">About</a>
          </router-link>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: 'TheHeaderNavbar'
}
</script>

<style type="text/css">
.navbar {
  font-family: 'Raleway', sans-serif;
}
</style>

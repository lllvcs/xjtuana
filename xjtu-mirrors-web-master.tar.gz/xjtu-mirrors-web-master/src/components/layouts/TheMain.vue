<template>
  <main
    class="container animated fadeIn"
    style="animation-delay: .8s;"
  >
    <TransitionFadeSlide>
      <router-view />
    </TransitionFadeSlide>
  </main>
</template>

<script>
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'TheMain',
  components: {
    TransitionFadeSlide
  }
}
</script>

<style type="text/css" scoped>
.container {
  min-height: 640px;
}
</style>

<template>
  <component
    :is="component"
    :name="name"
    :mode="mode"
    :appear="appear"
    :tag="tag"
  >
    <slot/>
  </component>
</template>

<script>
export default {
  name: 'TransitionFadeSlide',
  props: {
    appear: {
      type: Boolean,
      default: true
    },
    direction: {
      type: String,
      default: 'y'
    },
    group: {
      type: Boolean,
      default: false
    },
    mode: {
      type: String,
      default: 'out-in'
    },
    tag: {
      type: String,
      default: ''
    }
  },
  computed: {
    name () {
      return `fade-slide-${this.direction}`
    },
    component () {
      return this.group ? 'transition-group' : 'transition'
    }
  }
}
</script>

<style type="text/css">
.fade-slide-y-enter-active {
  transition: all .3s ease;
}
.fade-slide-y-leave-active {
  transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.fade-slide-y-enter, .fade-slide-y-leave-to {
  transform: translateY(10px);
  opacity: 0;
}

.fade-slide-x-enter-active {
  transition: all .3s ease;
}
.fade-slide-x-leave-active {
  transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.fade-slide-x-enter, .fade-slide-x-leave-to {
  transform: translateX(10px);
  opacity: 0;
}
</style>

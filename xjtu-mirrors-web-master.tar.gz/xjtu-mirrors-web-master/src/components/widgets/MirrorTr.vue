<template>
  <tr
    :class="trClass"
    :title="`同步状态：${mirror.status}`"
  >
    <td>
      <a
        :href="`http://mirrors.xjtu.edu.cn/${mirror.name}/`"
        target="_blank"
      >
        {{ mirror.name }}
      </a>
    </td>

    <td class="d-none d-md-table-cell">{{ mirror.last_update }}</td>

    <td class="mirror-info">
      <FontAwesomeIcon
        :icon="statusIcon.icon"
        :spin="statusIcon.spin"
        fixed-width
      />

      <router-link
        v-if="help"
        :to="{ name: 'help-detail', params: { name: mirror.name }}"
        title="点击查看帮助"
      >
        <FontAwesomeIcon
          :icon="faBook"
          fixed-width
        />
      </router-link>
    </td>
  </tr>
</template>

<script>
import faBook from '@fortawesome/fontawesome-free-solid/faBook'
import faCheck from '@fortawesome/fontawesome-free-solid/faCheck'
import faSpinner from '@fortawesome/fontawesome-free-solid/faSpinner'
import faExclamationTriangle from '@fortawesome/fontawesome-free-solid/faExclamationTriangle'
export default {
  name: 'MirrorTr',
  props: {
    mirror: {
      type: Object,
      required: true
    },
    help: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    trClass () {
      return {
        'table-warning': this.mirror.status === 'syncing',
        'table-danger': this.mirror.status === 'failed'
      }
    },
    faBook: () => faBook,
    statusIcon () {
      return this.mirror.status === 'success'
        ? { icon: faCheck, spin: false }
        : this.mirror.status === 'syncing'
          ? { icon: faSpinner, spin: true }
          : this.mirror.status === 'failed'
            ? { icon: faExclamationTriangle, spin: false }
            : null
    }
  }
}
</script>

<style type="text/css" lang="scss" scoped>
td {
  border-width: 0;
  &.mirror-info {
    a {
      color: black;
    }
    i {
      cursor: pointer
    }
  }
}
</style>

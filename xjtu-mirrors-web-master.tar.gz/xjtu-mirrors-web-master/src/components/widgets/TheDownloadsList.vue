<template>
  <section
    id="download-list"
    class="my-3"
  >
    <div class="mb-3">
      <span class="h4">
        <FontAwesomeIcon :icon="faDownload" />

        <span>资源下载 <sup><small>Downloads</small></sup></span>
      </span>
    </div>

    <TransitionFadeSlide direction="x">
      <ul>
        <li><a
          href="http://mirrors.xjtu.edu.cn/archlinux/iso/latest/"
          target="_blank">ArchLinux</a></li>

        <li><a
          href="http://mirrors.xjtu.edu.cn/centos/7/isos/x86_64/"
          target="_blank">CentOS</a></li>

        <li><a
          href="http://mirrors.xjtu.edu.cn/debian-cd/current/amd64/iso-cd/"
          target="_blank">Debian</a></li>

        <li><a
          href="http://mirrors.xjtu.edu.cn/fedora/releases/28/Workstation/x86_64/iso/"
          target="_blank">Fedora</a></li>

        <!--<li><a-->
        <!--  href="http://mirrors.xjtu.edu.cn/kali-images/current/"-->
        <!--  target="_blank">Kali Linux</a></li>-->

        <li><a
          href="http://mirrors.xjtu.edu.cn/kernel/"
          target="_blank">Linux Kernel</a></li>

        <li><a
          href="http://mirrors.xjtu.edu.cn/ubuntu-releases/"
          target="_blank">Ubuntu</a></li>
      </ul>
    </TransitionFadeSlide>
  </section>
</template>

<script>
import faDownload from '@fortawesome/fontawesome-free-solid/faDownload'
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'TheDownloadsList',
  components: {
    TransitionFadeSlide
  },
  computed: {
    faDownload: () => faDownload
  }
}
</script>

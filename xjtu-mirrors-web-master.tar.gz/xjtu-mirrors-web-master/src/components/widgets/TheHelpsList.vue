<template>
  <section class="my-3">
    <div class="d-none d-md-block">
      <div class="mb-3">
        <span class="h4">
          <FontAwesomeIcon :icon="faBook"/>

          <span>帮助文档 <sup><small>Helps</small></sup></span>
        </span>
      </div>

      <div>
        <ul class="list-unstyled">
          <li
            v-for="help in helps"
            :key="help"
          >
            <router-link :to="{ name: 'help-detail', params: { name: help } }">
              {{ help }}
            </router-link>
          </li>
        </ul>
      </div>
    </div>

    <div class="dropdown d-block d-md-none">
      <button
        class="btn btn-light dropdown-toggle text-left"
        type="button"
        data-toggle="dropdown"
      >
        <FontAwesomeIcon :icon="faBook"/>

        <span>选择帮助文档</span>
      </button>

      <div class="dropdown-menu">
        <router-link
          v-for="help in helps"
          :key="help"
          :to="{ name: 'help-detail', params: { name: help } }"
          class="dropdown-item"
        >
          {{ help }}
        </router-link>
      </div>
    </div>
  </section>
</template>

<script>
import faBook from '@fortawesome/fontawesome-free-solid/faBook'
import { mapGetters } from 'vuex'
export default {
  name: 'TheHelpsList',
  computed: {
    ...mapGetters([
      'helps'
    ]),
    faBook: () => faBook
  }
}
</script>

<template>
  <section
    id="links-list"
    class="my-3"
  >
    <div class="mb-3">
      <span class="h4">
        <FontAwesomeIcon :icon="faLink" />

        <span>相关链接 <sup><small>Links</small></sup></span>
      </span>
    </div>

    <TransitionFadeSlide direction="x">
      <ul>
        <li>
          <a
            href="http://nic.xjtu.edu.cn/"
            target="_blank">
            <span>西安交通大学网络信息中心</span>
          </a>
        </li>

        <li>
          <a
            href="https://ana.xjtu.edu.cn"
            target="_blank">
            <span>西安交通大学学生网络管理协会</span>
          </a>
        </li>

        <li>
          <a
            href="https://www.tiaozhan.com"
            target="_blank">
            <span>西安交通大学团委挑战网</span>
          </a>
        </li>
      </ul>
    </TransitionFadeSlide>
  </section>
</template>

<script>
import faLink from '@fortawesome/fontawesome-free-solid/faLink'
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'TheLinksList',
  components: {
    TransitionFadeSlide
  },
  computed: {
    faLink: () => faLink
  }
}
</script>

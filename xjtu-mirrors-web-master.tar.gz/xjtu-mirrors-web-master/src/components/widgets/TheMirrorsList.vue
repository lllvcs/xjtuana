<template>
  <section
    id="mirrors-list"
    class="my-3 mb-4"
  >
    <div class="mb-3 row">
      <span class="h4 col-sm-6">
        <FontAwesomeIcon :icon="faCoffee" />

        <span>镜像列表 <sup><small>Mirrors</small></sup></span>
      </span>

      <div class="text-right col-sm-6">
        <input
          v-show="mirrors !== null"
          v-model="condition"
          type="text"
          class="form-control"
          placeholder="Filter Mirrors"
        >
      </div>
    </div>

    <div>
      <TransitionFadeSlide
        direction="x"
        :appear="false"
      >
        <p v-if="filteredMirrors === null">
          正在获取镜像列表……<i class="fa fa-spin fa-spinner ml-2"/>
        </p>

        <p v-else-if="filteredMirrors.length === 0">
          暂无镜像
        </p>

        <table
          v-else
          class="table table-hover table-sm m-0"
        >
          <thead>
            <tr>
              <th>名称</th>

              <th class="d-none d-md-table-cell">最近更新时间</th>

              <th>说明</th>
            </tr>
          </thead>

          <TransitionFadeSlide
            direction="x"
            :group="true"
            tag="tbody"
          >
            <MirrorTr
              v-for="mirror in filteredMirrors"
              :key="mirror.name"
              :mirror="mirror"
              :help="helps.includes(mirror.name)"
            />
          </TransitionFadeSlide>
        </table>
      </TransitionFadeSlide>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
import MirrorTr from '@/components/widgets/MirrorTr'
import faCoffee from '@fortawesome/fontawesome-free-solid/faCoffee'
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'TheMirrorsList',
  components: {
    MirrorTr,
    TransitionFadeSlide
  },
  data () {
    return {
      condition: ''
    }
  },
  computed: {
    ...mapGetters([
      'mirrors',
      'helps'
    ]),
    faCoffee: () => faCoffee,
    filteredMirrors () {
      if (this.mirrors === null) return null
      let filteredMirrors = this.mirrors.filter(item => item.name.toLowerCase().includes(this.condition.toLowerCase()))
      return filteredMirrors
    }
  }
}
</script>

<style type="text/css" lang="scss" scope>
.table {
  border-bottom: 2px solid #e9ecef;
}
</style>

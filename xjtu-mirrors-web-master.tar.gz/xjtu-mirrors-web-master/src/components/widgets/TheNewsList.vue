<template>
  <section class="my-3">
    <div :class="responsiveClass">
      <div class="mb-3">
        <span class="h4">
          <FontAwesomeIcon :icon="faBullhorn" />

          <span>新闻通知 <sup><small>News</small></sup></span>
        </span>
      </div>

      <TransitionFadeSlide direction="x">
        <p v-if="news.length === 0">
          暂无新闻通知
        </p>

        <ul v-else>
          <li
            v-for="val in displayNews"
            :key="val.name"
          >
            <router-link :to="{ name: 'news-detail', params: { name: val.name } }">
              {{ val.title }}
            </router-link>

            <br>

            <sup class="text-muted">{{ val.date }}</sup>
          </li>
        </ul>
      </TransitionFadeSlide>
    </div>

    <div
      v-if="responsive"
      class="dropdown d-block d-md-none"
    >
      <button
        class="btn btn-light dropdown-toggle text-left"
        type="button"
        data-toggle="dropdown"
      >
        <FontAwesomeIcon :icon="faBullhorn"/>

        <span>选择新闻通知</span>
      </button>

      <div class="dropdown-menu">
        <router-link
          v-for="val in displayNews"
          :key="val.name"
          :to="{ name: 'news-detail', params: { name: val.name } }"
          class="dropdown-item"
        >
          {{ val.title }}
        </router-link>
      </div>
    </div>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import faBullhorn from '@fortawesome/fontawesome-free-solid/faBullhorn'
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'TheNewsList',
  components: {
    TransitionFadeSlide
  },
  props: {
    limit: {
      type: Number,
      default: 0
    },
    responsive: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    ...mapState([
      'news'
    ]),
    faBullhorn: () => faBullhorn,
    responsiveClass () {
      return {
        'd-none d-md-block': this.responsive
      }
    },
    displayNews () {
      let displayNews = this.limit > 0 ? this.news.slice(0, this.limit) : this.news
      return displayNews
    }
  }
}
</script>

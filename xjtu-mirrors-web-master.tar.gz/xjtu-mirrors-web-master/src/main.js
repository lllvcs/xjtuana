import '@/assets/sass/fonts.scss'
import '@/assets/sass/bootstrap.scss'
import 'github-markdown-css/github-markdown.css'
import 'animate.css/animate.css'

import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import FontAwesomeIcon from '@fortawesome/vue-fontawesome'
import VueShowdown from 'vue-showdown'

Vue.component('VueShowdown', VueShowdown)
Vue.component('FontAwesomeIcon', FontAwesomeIcon)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})

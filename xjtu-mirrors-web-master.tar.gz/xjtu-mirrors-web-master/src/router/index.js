import Vue from 'vue'
import Router from 'vue-router'
import store from '../store'

import Home from '@/views/index'
import Help from '@/views/help'
import HelpDetail from '@/views/help/_name'
import News from '@/views/news'
import NewsDetail from '@/views/news/_name'
import About from '@/views/about'
import NotFound from '@/views/404'

const newsIndex = store.state.news.length === 0 ? 'index' : store.state.news[0].name

Vue.use(Router)

const scrollToHash = hash => {
  const docEl = document.documentElement
  const docRect = docEl.getBoundingClientRect()
  const elRect = document.querySelector(hash).getBoundingClientRect()
  const scrollMaxY = docRect.height - docEl.clientHeight
  const scrollY = Math.min(elRect.top - docRect.top, scrollMaxY)
  scrollToY(scrollY)
}

const scrollToY = scrollY => {
  const scrollInterval = setInterval(() => {
    let distance = scrollY - window.scrollY
    let distanceAbs = Math.abs(distance)
    if (distanceAbs > 1) {
      distanceAbs < 100 ? window.scrollTo(0, scrollY) : window.scrollBy(0, distance / 5)
    } else {
      clearInterval(scrollInterval)
    }
  }, 15)
}

export default new Router({
  linkActiveClass: 'active',
  mode: 'history',
  scrollBehavior (to, from, saved) {
    if (saved) {
      return saved
    } else if (to.hash) {
      return scrollToHash(to.hash)
    } else {
      return scrollToY(0)
    }
  },
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/help',
      component: Help,
      children: [
        {
          path: '',
          name: 'help',
          redirect: { path: '/help/index' }
        },
        {
          path: '/help/:name',
          name: 'help-detail',
          component: HelpDetail
        }
      ]
    },
    {
      path: '/news',
      component: News,
      children: [
        {
          path: '',
          name: 'news',
          redirect: { path: `/news/${newsIndex}` }
        },
        {
          path: '/news/:name',
          name: 'news-detail',
          component: NewsDetail
        }
      ]
    },
    {
      path: '/about',
      name: 'about',
      component: About
    },
    {
      path: '*',
      component: NotFound
    }
  ]
})

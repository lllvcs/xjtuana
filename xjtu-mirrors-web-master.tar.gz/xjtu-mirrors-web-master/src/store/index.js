import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
import format from 'date-fns/format'
import helps from './data/helps'
import news from './data/news'
import status from './data/status'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    mirrorsData: status,
    helpsData: helps,
    news
  },
  mutations: {
    setMirrors (state, payload) {
      state.mirrorsData = payload
    }
  },
  actions: {
    async fetchMirrors ({ commit }) {
      try {
        const mirrors = await axios.get('//mirrors.xjtu.edu.cn/api/status.json')
        commit('setMirrors', mirrors.data)
      } catch (e) {
        console.log(e)
      }
    }
  },
  getters: {
    mirrors (state) {
      if (state.mirrorsData === null) {
        return []
      }
      // Sort and normalize the mirrorsData
      const mirrors = Object.values(state.mirrorsData)
        .sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()))
        .map(item => {
          item.last_update = format(item.last_update, 'YYYY-MM-DD HH:mm:ss')
          item.last_ended = format(item.last_ended, 'YYYY-MM-DD HH:mm:ss')
          return item
        })
      return mirrors
    },

    helps (state, getters) {
      if (state.helpsData === null) {
        return null
      }
      // Sort and normalize the mirrorsData
      const helps = state.helpsData.filter(help => getters.mirrors.find(mirror => mirror.name === help))
      return helps
    }
  }
})

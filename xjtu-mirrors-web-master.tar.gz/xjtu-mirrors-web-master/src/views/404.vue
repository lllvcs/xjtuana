<template>
  <div class="row">
    404 NotFound
  </div>
</template>

<script>
export default {
  name: 'NotFound'
}
</script>

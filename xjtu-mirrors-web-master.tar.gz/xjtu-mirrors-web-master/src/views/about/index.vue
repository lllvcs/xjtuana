<template>
  <article class="p-2">
    <section class="p-2">
      <h3>
        <FontAwesomeIcon :icon="faPeopleCarry" />
        运维团队
      </h3>

      <section class="py-2">
        <p>
          西安交通大学开源软件镜像站由<a
            href="http://nic.xjtu.edu.cn"
            target="_blank">西安交通大学网络信息中心</a>指导，提供设备与资源支持。
        </p>

        <p>
          现运维团队为<a
            href="https://ana.xjtu.edu.cn"
            target="_blank">西安交通大学学生网络管理协会</a>，简称西交网管会。西交网管会成立于2014年，于2017年获评校甲级社团。社团致力于服务同学，主要职责为校园网络故障排查与维修，处理同学们的网络问题。同时网管会积极参与各项校园信息化项目开发，为校园网络建设添砖加瓦。
        </p>

        <p>
          原运维团队为<a
            href="https://www.tiaozhan.com"
            target="_blank">西安交通大学挑战网</a>，于2018年将运维工作移交至西交网管会。感谢挑战网对西交镜像站的付出与大力支持！
        </p>
      </section>
    </section>

    <!--<section class="p-2">-->
    <!--  <h3>-->
    <!--    <FontAwesomeIcon :icon="faCubes" />-->
    <!--    技术支持-->
    <!--  </h3>-->

    <!--  <section class="py-2">-->
    <!--    <p>-->
    <!--      本镜像站网站页面（<a-->
    <!--        href="https://git.xjtuana.com/xjtuana/xjtu-mirrors-web"-->
    <!--        target="_blank">查看源码</a>）由西交网管会研发部开发维护。-->
    <!--    </p>-->

    <!--    <p>-->
    <!--      本镜像站镜像同步方案来自<a-->
    <!--        href="https://tuna.moe"-->
    <!--        target="_blank">清华大学TUNA协会</a>贡献的开源项目<a-->
    <!--          href="https://github.com/tuna/tunasync"-->
    <!--          target="_blank">tunasync</a>。-->
    <!--    </p>-->
    <!--  </section>-->
    <!--</section>-->

    <section class="p-2">
      <h3>
        <FontAwesomeIcon :icon="faEnvelope" />
        联系我们
      </h3>

      <section class="py-2">
        <p>
          <span>西交镜像站运维团队: </span>
          <a href="mailto:mirrors@xjtu.edu.cn">mirrors@xjtu.edu.cn</a>
        </p>
      </section>
    </section>
  </article>
</template>

<script>
import faPeopleCarry from '@fortawesome/fontawesome-free-solid/faPeopleCarry'
import faEnvelope from '@fortawesome/fontawesome-free-solid/faEnvelope'
import faCubes from '@fortawesome/fontawesome-free-solid/faCubes'
export default {
  name: 'About',
  computed: {
    faPeopleCarry: () => faPeopleCarry,
    faEnvelope: () => faEnvelope,
    faCubes: () => faCubes
  }
}
</script>

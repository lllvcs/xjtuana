<template>
  <div class="pt-3 pb-5">
    <p v-if="loading">
      Loading ……<i class="fa fa-spin fa-spinner ml-2"/>
    </p>

    <VueShowdown
      v-if="md"
      :markdown="md"
      class="markdown-body"
    />
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'HelpDetail',
  data () {
    return {
      md: null,
      loading: false
    }
  },
  watch: {
    '$route.params.name' () {
      this.fetchData()
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    async fetchData () {
      this.loading = true
      try {
        let response = await axios.get(`/static/md/help/${this.$route.params.name}.md`)
        this.md = response.data
      } catch (error) {
        this.md = error.message
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<template>
  <div class="row">
    <div class="col-md-4 col-lg-3">
      <TheHelpsList />
    </div>

    <div class="col-md-8 col-lg-9">
      <TransitionFadeSlide>
        <router-view :key="$route.params.name" />
      </TransitionFadeSlide>
    </div>
  </div>
</template>

<script>
import TheHelpsList from '@/components/widgets/TheHelpsList'
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'Help',
  components: {
    TheHelpsList,
    TransitionFadeSlide
  }
}
</script>

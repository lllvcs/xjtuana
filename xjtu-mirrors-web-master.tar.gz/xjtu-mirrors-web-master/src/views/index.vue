<template>
  <div class="row">
    <TheMirrorsList class="col-md-8" />

    <div class="col-md-4">
      <TheNewsList :limit="3" />

      <hr>

      <TheDownloadsList />

      <hr>

      <TheLinksList />
    </div>
  </div>
</template>

<script>
import TheMirrorsList from '@/components/widgets/TheMirrorsList'
import TheNewsList from '@/components/widgets/TheNewsList'
import TheDownloadsList from '@/components/widgets/TheDownloadsList'
import TheLinksList from '@/components/widgets/TheLinksList'
export default {
  name: 'Home',
  components: {
    TheMirrorsList,
    TheNewsList,
    TheDownloadsList,
    TheLinksList
  }
}
</script>

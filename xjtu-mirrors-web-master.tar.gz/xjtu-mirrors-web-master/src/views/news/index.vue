<template>
  <div class="row">
    <div class="col-md-4 col-lg-3">
      <TheNewsList :responsive="true" />
    </div>

    <div class="col-md-8 col-lg-9">
      <TransitionFadeSlide>
        <router-view :key="$route.params.name" />
      </TransitionFadeSlide>
    </div>
  </div>
</template>

<script>
import TheNewsList from '@/components/widgets/TheNewsList'
import TransitionFadeSlide from '@/components/transitions/TransitionFadeSlide'
export default {
  name: 'News',
  components: {
    TheNewsList,
    TransitionFadeSlide
  }
}
</script>

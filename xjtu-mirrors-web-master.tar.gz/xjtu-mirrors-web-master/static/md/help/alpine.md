# Alpine 镜像使用帮助

Alpine Linux是一个注重安全、轻量级的Linux发行版，基于musl libc 和 busybox，广泛用于嵌入式、容器操作系统。

## 收录架构

- ALL

## 收录版本

- ALL

## 使用说明

编辑/etc/apk/repositories：

```code
http://mirrors.xjtu.edu.cn/alpine/v3.4/main
http://mirrors.xjtu.edu.cn/alpine/v3.4/community
```

上述URL中的`v3.4`请自行修改为对应Alpine的版本。

## 相关链接

官方主页: https://www.alpinelinux.org/

APK包管理Wiki: https://wiki.alpinelinux.org/wiki/Alpine_Linux_package_management

# Docker Engine 镜像使用帮助

本镜像提供 Debian/Ubuntu/Fedora/CentOS/RHEL 的 docker 软件包。

## 收录架构

- ALL

## 收录版本

- ALL

## 使用说明

 - 对于`Debian/Ubuntu`用户，首先信任 Docker 的 GPG 公钥：

```code
apt-key adv --keyserver hkp://p80.pool.sks-keyservers.net:80 --recv-keys 58118E89F3A912897C070ADBF76221572C52609D
```

然后执行：

```code
echo "deb https://mirrors.xjtu.edu.cn/docker-engine/apt/repo debian-jessie main" > /etc/apt/sources.list.d/docker.list
```

上述URL中的`debian-jessie`请自行修改为你发行版的版本，点这里[查看](http://mirrors.xjtu.edu.cn/docker-engine/apt/repo/dists/)

更新源，安装docker：

```code
apt-get update
apt-get install docker-engine
```

 - 对于`Fedora/CentOS/RHEL`用户：

新建`/etc/yum.repos.d/docker.repo`文件，添加如下内容：

```code
[dockerrepo]
name=Docker Repository
baseurl=https://mirrors.xjtu.edu.cn/docker-engine/yum/repo/centos7
enabled=1
gpgcheck=1
gpgkey=https://mirrors.xjtu.edu.cn/docker-engine/yum/gpg
```

上述URL中的`centos7`请自行修改为你发行版的版本，点这里[查看](http://mirrors.xjtu.edu.cn/docker-engine/yum/repo/)

刷新源缓存并安装docker：

```code
yum makecache
yum install docker-engine
```

## 相关链接

官方主页: https://www.docker.com/

官方文档: https://docs.docker.com/

# Homebrew 镜像使用帮助

brew是Mac OSX系统的第三方包管理工具。该镜像是 Homebrew 的 Formula 索引的镜像。

本镜像站同时提供 Homebrew 二进制预编译包的镜像，请参考 Homebrew bottles 镜像使用帮助。

## 收录架构

- ALL

## 收录版本

- ALL

## 使用说明

替换现有Git remote：

```code
cd /usr/local
git remote set-url origin https://mirrors.xjtu.edu.cn/homebrew/brew.git

cd /usr/local/Library/Taps/homebrew/homebrew-core
git remote set-url origin https://mirrors.xjtu.edu.cn/homebrew/homebrew-core.git

brew update
```

如果你使用`homebrew-science`：

```code
cd /usr/local/Library/Taps/homebrew/homebrew-science
git remote set-url origin https://mirrors.xjtu.edu.cn/homebrew/homebrew-science.git

brew update
```

如果你使用`homebrew-python`：

```code
cd /usr/local/Library/Taps/homebrew/homebrew-python
git remote set-url origin https://mirrors.xjtu.edu.cn/homebrew/homebrew-python.git

brew update
```

## 相关链接

官方主页: http://brew.sh/

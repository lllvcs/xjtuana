# XJTU开源镜像使用帮助

请点击左侧菜单查看相应的镜像帮助。

如果你有任何建议和意见，欢迎通过邮件联系我们：

__西交镜像站运维团队: [mirrors@xjtu.edu.cn](mailto:mirrors@xjtu.edu.cn)__

## 域名与访问协议

本镜像站使用以下域名：

 - 主域名：`mirrors.xjtu.edu.cn`（支持`http/https`协议访问，自动解析 `IPv4`/`IPv6`）

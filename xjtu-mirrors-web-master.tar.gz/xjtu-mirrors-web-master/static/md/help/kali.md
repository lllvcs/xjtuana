# Kali镜像使用帮助

## 收录架构

- amd64
- i386

## 收录版本

- current
- dev
- testing
- experimental

## 使用说明

以 1.1.0版本为例, 编辑 /etc/apt/sources.list 文件, 在文件最前面添加以下条目：

运行apt-get update生成缓存。

```code
deb http://mirrors.xjtu.edu.cn/kali kali main non-free contrib
deb-src http://mirrors.xjtu.edu.cn/kali kali main non-free contrib
deb http://mirrors.xjtu.edu.cn/kali-security kali/updates main contrib non-free
```
对于 Kali 2.0，使用ipv4网络添加如下内容

```code
deb http://mirrors.xjtu.edu.cn/kali sana main non-free contrib
deb-src http://mirrors.xjtu.edu.cn/kali sana main non-free contrib
deb http://mirrors.xjtu.edu.cn/kali-security sana/updates main contrib non-free
```

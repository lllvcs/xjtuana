# MongoDB 镜像使用帮助

MongoDB 镜像自 [官方仓库](https://repo.mongodb.org/)， 目前有 RHEL/CentOS, Ubuntu, Debian 的镜像，仅支持 x86-64 架构。

## 收录架构

- ALL

## 收录版本

- ALL

## 使用说明

 - Debian/Ubuntu 用户

首先信任 MongoDB 的 GPG 公钥:

```code
apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv EA312927
```

如果是`debian wheezy`，添加源：

```code
echo 'deb http://mirrors.xjtu.edu.cn/mongodb/apt/debian wheezy/mongodb-org/stable main' > /etc/apt/sources.list.d/mongodb.list
```

上述URL中的`wheezy`请自行修改为对应版本号。

如果是`Ubuntu 14.04 LTS`，添加源：

```code
echo 'deb http://mirrors.xjtu.edu.cn/mongodb/apt/ubuntu trusty/mongodb-org/stable multiverse' > /etc/apt/sources.list.d/mongodb.list
```

上述URL中的`trusty`请自行修改为对应版本号。

更新源，安装mongodb-org:

```code
apt-get update
apt-get install -y mongodb-org
```

 - RHEL/CentOS 用户

新建`/etc/yum.repos.d/mongodb.repo`，内容为:

```code
[mongodb-org]
name=MongoDB Repository
baseurl=http://mirrors.xjtu.edu.cn/mongodb/yum/$releasever/
gpgcheck=0
enabled=1
```

刷新源缓存，安装mongodb-org:

```code
yum makecache
yum install mongodb-org
```

## 相关链接

官方主页: https://www.mongodb.com/

官方安装参考: https://docs.mongodb.org/master/administration/install-on-linux/

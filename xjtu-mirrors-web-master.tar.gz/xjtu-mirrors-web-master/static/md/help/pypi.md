# pypi 镜像使用帮助

## 临时使用

```code
pip install -i https://mirrors.xjtu.edu.cn/pypi/web/simple/ some-package
```

注意，simple 不能少, 是 https 而不是 http。

## 设为默认

修改 ~/.pip/pip.conf (没有就创建一个)

```code
[global]
index-url = https://mirrors.xjtu.edu.cn/pypi/web/simple/
```

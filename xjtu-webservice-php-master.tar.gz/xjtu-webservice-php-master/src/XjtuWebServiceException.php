<?php

namespace Xjtuana\XjtuWs\WebService;

class XjtuWebServiceException extends \Exception {}